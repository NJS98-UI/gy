#!/bin/bash
set -e

# ============================================================
# 应用管家上游升级脚本
# 用法: bash upgrade.sh /path/to/new_appmanager.apk
# 流程:
#   1. 反编译新版应用管家 APK
#   2. 全局替换包名 com.yunpan.appmanage -> com.ahcjzs
#   3. 替换应用图标 gj_ico.png / 应用名 app_name
#   4. 禁用原版自更新机制 (.gj123.apk 下载安装链路)
#   5. 校验 z9.g / MyProgressViewTest 兼容性
#   6. 调用 build.sh 注入 AppStoreFragment + LicenseUtil，打包签名
# ============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

NEW_APK="${1:?用法: bash upgrade.sh /path/to/new_appmanager.apk}"
NEW_APK="$(realpath "$NEW_APK")"
[ -f "$NEW_APK" ] || { echo "错误: APK 不存在: $NEW_APK"; exit 1; }

WORK="$SCRIPT_DIR"
GONGQIAN="$WORK/gongqian_apk"
TOOLS="$WORK/tools"
APKTOOL="$TOOLS/apktool.jar"
OLD_PKG="com.yunpan.appmanage"
NEW_PKG="com.ahcjzs"
OLD_PKG_PATH="com/yunpan/appmanage"
NEW_PKG_PATH="com/ahcjzs"
BACKUP="$WORK/upgrade_backup/$(date +%Y%m%d_%H%M%S)"
ICON_SRC="$WORK/assets/gj_ico.png"
# 非交互模式: 设置 SKIP_CONFIRM=1 跳过所有 read 确认 (供 CI/GitHub Actions 使用)
SKIP_CONFIRM="${SKIP_CONFIRM:-0}"
# 目标版本号: 商店自身更新要求 versionCode 大于已装版本才触发更新, 这里覆盖输入 APK 的版本
NEW_VERSION_CODE="1907"
NEW_VERSION_NAME="1.9.1"

echo "=== 应用管家升级脚本 ==="
echo "新版 APK: $NEW_APK"
echo "包名: $OLD_PKG -> $NEW_PKG"

# ---- Step 1: 准备 apktool ----
echo ""
echo "=== Step 1: 准备 apktool ==="
if [ ! -f "$APKTOOL" ]; then
    echo "下载 apktool 2.9.3..."
    mkdir -p "$TOOLS"
    curl -sL "https://github.com/iBotPeaches/Apktool/releases/download/v2.9.3/apktool_2.9.3.jar" -o "$APKTOOL"
fi

# ---- Step 2: 反编译新版 APK ----
echo ""
echo "=== Step 2: 反编译新版 APK ==="
DECOMP_DIR="$WORK/.upgrade_tmp"
rm -rf "$DECOMP_DIR"
mkdir -p "$DECOMP_DIR"
java -jar "$APKTOOL" d -f -o "$DECOMP_DIR/apk" "$NEW_APK" 2>&1

# 校验反编译产物
[ -d "$DECOMP_DIR/apk/smali" ] || { echo "错误: 反编译失败, 无 smali 目录"; exit 1; }

OLD_PKG_FOUND=$(grep -rl "$OLD_PKG" "$DECOMP_DIR/apk/" --include="*.smali" --include="*.xml" 2>/dev/null | wc -l)
if [ "$OLD_PKG_FOUND" -eq 0 ]; then
    echo "警告: 新版 APK 中未找到原包名 $OLD_PKG !"
    echo "        请确认: 新版确实是原版应用管家? 包名是否正确?"
    echo "        (若包名不同, 请编辑本脚本第 28 行 OLD_PKG 变量)"
    if [ "$SKIP_CONFIRM" != "1" ]; then
        read -r -p "包名不符, 是否强制继续? (y/N) " ans
        [ "$ans" = "y" ] || { echo "已取消。"; rm -rf "$DECOMP_DIR"; exit 1; }
    else
        echo "  (SKIP_CONFIRM=1, 忽略包名不符警告强制继续)"
    fi
fi

# ---- Step 3: 备份当前定制版 ----
echo ""
echo "=== Step 3: 备份当前定制版到 $BACKUP ==="
mkdir -p "$BACKUP"
if [ -d "$GONGQIAN" ]; then
    cp -r "$GONGQIAN" "$BACKUP/gongqian_apk"
    echo "已备份旧 gongqian_apk ($(du -sh "$BACKUP/gongqian_apk" 2>/dev/null | cut -f1))"
fi

# ---- Step 4: 替换 gongqian_apk ----
echo ""
echo "=== Step 4: 用新版替换 gongqian_apk ==="
rm -rf "$GONGQIAN"
mv "$DECOMP_DIR/apk" "$GONGQIAN"
rm -rf "$DECOMP_DIR"

# ---- Step 4.5: 升版本号 ----
# apktool 反编译会把输入 APK 的版本写进 apktool.yml, 重新打包时沿用该版本。
# 这里覆盖为目标版本, 使 versionCode 大于已装版本从而触发商店自身更新。
echo ""
echo "=== Step 4.5: 升版本号 ==="
sed -i -E "s/versionCode: ['\"]?[0-9]+['\"]?/versionCode: ${NEW_VERSION_CODE}/" "$GONGQIAN/apktool.yml"
sed -i -E "s/versionName: .*/versionName: ${NEW_VERSION_NAME}/" "$GONGQIAN/apktool.yml"
grep -E "versionCode|versionName" "$GONGQIAN/apktool.yml"

# ---- Step 5: 全局替换包名 ----
echo ""
echo "=== Step 5: 全局替换包名 $OLD_PKG -> $NEW_PKG ==="
# 5a. 文件路径: Lcom/yunpan/appmanage/ 目录重命名
find "$GONGQIAN/smali" "$GONGQIAN/smali_classes2" "$GONGQIAN/smali_classes3" \
    -type d -path "*/com/yunpan/appmanage*" 2>/dev/null | sort -r | while read -r d; do
    new="${d/$OLD_PKG_PATH/$NEW_PKG_PATH}"
    mkdir -p "$(dirname "$new")"
    mv "$d" "$new"
    echo "  重命名目录: $d"
done
# 如果新版没有独立 smali_classes2/3 目录, 确保存在
mkdir -p "$GONGQIAN/smali_classes2" "$GONGQIAN/smali_classes3"

# 5b. 文本替换: 所有 smali/xml 及文本类 assets 中的字符串
#     排除 META-INF/ original/ 以及打包时自动重建的目录
find "$GONGQIAN" -type f \( -name "*.smali" -o -name "*.xml" -o -name "*.txt" -o -name "*.json" -o -name "*.properties" \) \
    -not -path "*/META-INF/*" -not -path "*/original/*" 2>/dev/null | while read -r f; do
    if grep -q -e "$OLD_PKG" -e "$OLD_PKG_PATH" "$f" 2>/dev/null; then
        sed -i "s/${OLD_PKG//./\\.}/${NEW_PKG}/g" "$f"
        sed -i "s|${OLD_PKG_PATH}|${NEW_PKG_PATH}|g" "$f"
        echo "  文本替换: ${f#$GONGQIAN/}"
    fi
done

# 5c. AndroidManifest.xml 中的 android:name/provider authorities 已在 5b 覆盖
#     assets 二进制文件保留原名 (运行时字符串已在代码层替换)
echo "包名替换完成。"

# ---- Step 6: 替换图标 ----
echo ""
echo "=== Step 6: 替换应用图标 ==="
if [ -f "$ICON_SRC" ]; then
    # 新版图标引用 @mipmap/ic_launcher, 复制 gj_ico.png 并改 manifest 引用
    cp "$ICON_SRC" "$GONGQIAN/res/drawable-xhdpi/gj_ico.png"
    echo "  已复制 gj_ico.png"
    # 修改 manifest: @mipmap/ic_launcher -> @drawable/gj_ico
    sed -i 's#android:icon="@mipmap/ic_launcher"#android:icon="@drawable/gj_ico"#' "$GONGQIAN/AndroidManifest.xml"
    sed -i 's#android:roundIcon="@mipmap/ic_launcher_round"#android:roundIcon="@drawable/gj_ico"#' "$GONGQIAN/AndroidManifest.xml"
    echo "  manifest 图标引用已改为 @drawable/gj_ico"
else
    echo "  警告: 未找到 $ICON_SRC, 跳过图标替换"
fi

# ---- Step 7: 替换应用名 ----
echo ""
echo "=== Step 7: 替换应用名 ==="
for sf in "$GONGQIAN"/res/values*/strings.xml; do
    [ -f "$sf" ] || continue
    if grep -q 'name="app_name"' "$sf"; then
        sed -i 's#<string name="app_name">[^<]*</string>#<string name="app_name">阿辉应用管家</string>#' "$sf"
        echo "  已替换 app_name: ${sf#$GONGQIAN/}"
    fi
done

# ---- Step 8: 禁用原版自更新机制 ----
echo ""
echo "=== Step 8: 禁用原版自更新机制 ==="
# 原理: 把原版更新链路的下载路径 .gj123.apk 打点为无效路径,
#        更新流程运行后找不到目标文件自动失败, 不断类引用、不破坏 smali 结构
DISABLED_FILES=$(grep -rl "\.gj123\.apk\|.gj123" "$GONGQIAN/smali" 2>/dev/null | wc -l)
if [ "$DISABLED_FILES" -gt 0 ]; then
    grep -rl "\.gj123\.apk\|.gj123" "$GONGQIAN/smali" 2>/dev/null | while read -r f; do
        sed -i 's#\.gj123\.apk#.gj_disabled#g' "$f"
        echo "  禁用更新写路径: ${f#$GONGQIAN/}"
    done
else
    echo "  未发现 .gj123.apk 更新链路 (新版可能已改机制, 建议人工确认)"
fi

# ---- Step 9: 兼容性校验 ----
echo ""
echo "=== Step 9: 兼容性校验 ==="
Z9_OK=0
[ -f "$GONGQIAN/smali/z9/g.smali" ] && Z9_OK=1
if [ "$Z9_OK" -eq 0 ]; then
    echo "  !! 注意: 新版未找到 z9/g.smali (AppStoreFragment 的父类)"
    echo "     AppStoreFragment extends z9.g, 新版若混淆名变化需要调整 stubsrc/z9/g.java"
    echo "     建议先运行 build.sh, 若编译/打包失败再处理"
else
    echo "  z9/g.smali 存在, 父类兼容可尝试直接构建"
fi

MPV=$(find "$GONGQIAN/smali" "$GONGQIAN/smali_classes2" "$GONGQIAN/smali_classes3" -name "MyProgressViewTest.smali" 2>/dev/null | head -1)
if [ -n "$MPV" ]; then
    echo "  MyProgressViewTest 存在: $MPV"
else
    echo "  !! 注意: 未找到 MyProgressViewTest.smali (新版可能重命名, 需调整 stub)"
fi

grep -q "$NEW_PKG" "$GONGQIAN/AndroidManifest.xml" || \
    { echo "  !! 注意: AndroidManifest 未包含新包名, 请检查"; }

# ---- Step 10: 调用 build.sh ----
echo ""
echo "=== Step 10: 注入你的代码并打包 ==="
if [ -f "$WORK/build.sh" ]; then
    bash "$WORK/build.sh"
else
    echo "警告: build.sh 不存在, 请手动构建"
fi

echo ""
echo "=== 升级完成! ==="
echo "产物: $WORK/gongqian_appstore_signed.apk"
echo "如需回滚: 恢复备份目录 $BACKUP/gongqian_apk 到 $GONGQIAN 后重新 build.sh"