#!/bin/bash
set -e

# ============================================================
# 公签版应用商店 - 自包含编译脚本
# 使用仓库内相对路径，无需外部依赖
# ============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

WORK="$SCRIPT_DIR"
GONGQIAN="$WORK/gongqian_apk"
JAVASRC="$WORK/src"
STUBSRC="$WORK/stubsrc"
TOOLS="$WORK/tools"
ANDROID_JAR="$TOOLS/android.jar"

# ===== Step 0: 准备编译工具 =====
echo "=== Step 0: 准备编译工具 ==="

mkdir -p "$TOOLS"

# 下载 apktool 2.9.3
if [ ! -f "$TOOLS/apktool.jar" ]; then
    echo "下载 apktool 2.9.3..."
    curl -sL "https://github.com/iBotPeaches/Apktool/releases/download/v2.9.3/apktool_2.9.3.jar" -o "$TOOLS/apktool.jar"
fi

# 下载 baksmali 2.5.2（优先使用仓库内 tools 下的 fat jar，避免外部源失效/损坏）
if [ ! -f "$TOOLS/baksmali.jar" ] || ! unzip -l "$TOOLS/baksmali.jar" >/dev/null 2>&1; then
    echo "下载 baksmali 2.5.2..."
    curl -sL "https://bitbucket.org/JesusFreke/smali/downloads/baksmali-2.5.2.jar" -o "$TOOLS/baksmali.jar"
    # 校验 JAR 完整性，损坏则报错
    if ! unzip -l "$TOOLS/baksmali.jar" >/dev/null 2>&1; then
        echo "ERROR: baksmali.jar 下载损坏" >&2
        exit 1
    fi
fi
if [ -f "$WORK/toolchain/baksmali.jar" ]; then
    cp "$WORK/toolchain/baksmali.jar" "$TOOLS/baksmali.jar"
fi

# 下载 android.jar (API 33)
if [ ! -f "$ANDROID_JAR" ] || [ $(stat -c%s "$ANDROID_JAR" 2>/dev/null || echo 0) -lt 1000000 ]; then
    echo "下载 android.jar (API 33)..."
    curl -sL "https://raw.githubusercontent.com/Sable/android-platforms/master/android-33/android.jar" -o "$ANDROID_JAR"
    # 备用下载地址
    if [ ! -s "$ANDROID_JAR" ] || [ $(stat -c%s "$ANDROID_JAR" 2>/dev/null || echo 0) -lt 1000000 ]; then
        echo "备用下载 android.jar..."
        curl -sL "https://github.com/Sable/android-platforms/raw/master/android-33/android.jar" -o "$ANDROID_JAR"
    fi
fi

# 下载 zipalign 和 apksigner (从 Android build-tools)
if [ ! -f "$TOOLS/zipalign" ]; then
    echo "下载 Android build-tools..."
    BT_URL="https://dl.google.com/android/repository/build-tools_r34-linux.zip"
    curl -sL "$BT_URL" -o "$TOOLS/build-tools.zip"
    cd "$TOOLS"
    unzip -q -o build-tools.zip
    BT_DIR=$(ls -d android-*/ | head -1)
    if [ -n "$BT_DIR" ]; then
        cp "$BT_DIR/zipalign" ./
        cp "$BT_DIR/apksigner" ./
        cp "$BT_DIR/lib/apksigner.jar" ./ 2>/dev/null || true
        cp "$BT_DIR/lib/d8.jar" ./ 2>/dev/null || true
        # zipalign 依赖 libc++.so，复制原生库目录
        cp -r "$BT_DIR/lib64" ./ 2>/dev/null || true
    fi
    rm -f build-tools.zip
    cd "$WORK"
fi

echo "工具准备完成。"

# ===== Step 1: 编译 Java 源码 =====
echo "=== Step 1: 编译 Java 源码 ==="
rm -rf "$WORK/classes_out"
mkdir -p "$WORK/classes_out"

javac -source 8 -target 8 -bootclasspath "$ANDROID_JAR" \
    -cp "$ANDROID_JAR" \
    -d "$WORK/classes_out" \
    "$STUBSRC/z9/g.java" \
    "$STUBSRC/z9/p.java" \
    "$STUBSRC/androidx/core/content/FileProvider.java" \
    "$STUBSRC/com/ahcjzs/view/MyProgressViewTest.java" \
    "$STUBSRC/w8/n.java" \
    "$STUBSRC/com/ahcjzs/util/v.java" \
    "$STUBSRC/com/ahcjzs/util/w.java" \
    "$STUBSRC/ia/d.java" \
    "$STUBSRC/ia/e.java" \
    "$JAVASRC/com/appstore/LicenseUtil.java" \
    "$JAVASRC/com/appstore/AppStoreFragment.java" 2>&1

echo "Java 编译完成。"

# ===== Step 2: 编译 class 到 DEX =====
echo "=== Step 2: 编译 class 到 DEX ==="
rm -rf "$WORK/dex_out"
mkdir -p "$WORK/dex_out"

find "$WORK/classes_out" -name "*.class" > "$WORK/classlist.txt"
# d8 主类来自 build-tools 的 d8.jar；若存在则直接用，否则退回 r8.jar
D8_JAR="$TOOLS/d8.jar"
if [ ! -f "$D8_JAR" ]; then
    D8_JAR="$TOOLS/r8.jar"
fi
java -cp "$D8_JAR" com.android.tools.r8.D8 \
    --output "$WORK/dex_out" \
    --min-api 21 \
    --lib "$ANDROID_JAR" \
    @"$WORK/classlist.txt" 2>&1

echo "DEX 编译完成。"

# ===== Step 3: DEX 转 smali =====
echo "=== Step 3: DEX 转 smali ==="
rm -rf "$WORK/smali_out"
mkdir -p "$WORK/smali_out"

java -jar "$TOOLS/baksmali.jar" disassemble \
    "$WORK/dex_out/classes.dex" \
    -o "$WORK/smali_out" 2>&1

echo "smali 转换完成。"

# ===== Step 4: 替换 APK 中的 smali 文件 =====
echo "=== Step 4: 替换 smali 文件 ==="
mkdir -p "$GONGQIAN/smali_classes2/com/appstore"
rm -rf "$GONGQIAN/smali_classes2/com/appstore/"
cp -r "$WORK/smali_out/com/appstore/" "$GONGQIAN/smali_classes2/com/appstore/"
# 注入 stub 类：z9/g（AppStoreFragment 超类）、MyProgressViewTest（下载进度组件）
if [ -d "$WORK/smali_out/z9" ]; then
    mkdir -p "$GONGQIAN/smali_classes2/z9"
    rm -rf "$GONGQIAN/smali_classes2/z9/"
    cp -r "$WORK/smali_out/z9/" "$GONGQIAN/smali_classes2/z9/"
fi
if [ -d "$WORK/smali_out/com/ahcjzs/view" ]; then
    mkdir -p "$GONGQIAN/smali_classes2/com/ahcjzs/view"
    rm -rf "$GONGQIAN/smali_classes2/com/ahcjzs/view/"
    cp -r "$WORK/smali_out/com/ahcjzs/view/" "$GONGQIAN/smali_classes2/com/ahcjzs/view/"
fi

echo "smali 替换完成。"

# ===== Step 4.4: 解锁安装器设置（公签版强制管家安装器 → 跟随用户所选）=====
echo "=== Step 4.4: 解锁安装器设置 ==="
if [ -f "$WORK/unlock_installer_mode.py" ]; then
    python3 "$WORK/unlock_installer_mode.py" "$GONGQIAN"
else
    echo "  !! 警告: unlock_installer_mode.py 未找到, 跳过安装器设置解锁"
fi
echo "安装器设置解锁完成。"

# ===== Step 4.5: 注入应用商店入口 =====
echo "=== Step 4.5: 注入应用商店入口 ==="

# 修改 ActivityHome.smali
AH="$GONGQIAN/smali/com/ahcjzs/ui/ActivityHome.smali"
if [ -f "$AH" ]; then
    export AH_PATH="$AH"
    python3 << 'PYEOF'
import re, os

ah = os.environ['AH_PATH']
with open(ah, 'r') as f:
    c = f.read()

modified = False
_warn = 0

# 0) 检查是否已注入过（防止重复注入）
if 'Lcom/appstore/AppStoreFragment;->preload' in c:
    print("  ActivityHome.smali: 已包含应用商店注入, 跳过所有注入")
    with open(ah, 'w') as f:
        f.write(c)
    import sys; sys.exit(0)

# 1) 在 onCreate 方法开头注入 preload 调用
m = re.search(r'(\.method public final onCreate\(Landroid/os/Bundle;\)V\n    \.locals \d+\n\n)(    \.line 1\n)', c)
if m:
    preload = ("    # Trigger AppStoreFragment class loading to start JSON+icon preloading and store update check immediately\n"
               "    invoke-static {p0}, Lcom/appstore/AppStoreFragment;->preload(Landroid/content/Context;)V\n\n")
    c = c[:m.start(2)] + preload + c[m.start(2):]
    modified = True
    print("  ActivityHome.smali: 已添加 preload 调用 (onCreate)")
else:
    _warn += 1
    print("  !! 警告: 未找到 onCreate 的 .locals 锚点")

# 2) 标题导航重排: 应用商店 -> 功能面板 -> 文件管理 -> 网络存储
#    在原 功能面板 标题之前插入 应用商店(默认选中)
#    原 功能面板 默认选中改为不选中
FUNCPANEL = r'const-string\s+(v\d+),\s*"\\u529f\\u80fd\\u9762\\u677f"'
FILES = r'const-string\s+(v\d+),\s*"\\u6587\\u4ef6\\u7ba1\\u7406"'
CLOUD = r'const-string\s+(v\d+),\s*"\\u7f51\\u7edc\\u5b58\\u50a8"'
TC_RE = re.compile(r'new-instance\s+(v\d+),\s*Lt9/h3;')

# 三条 const-string 均落在 u() 标题列表区；功能面板 1 处、文件管理/网络存储各 2 处(另一处为其它方法)
fp_m = list(re.finditer(FUNCPANEL, c))
fj_m = list(re.finditer(FILES, c))
cl_m = list(re.finditer(CLOUD, c))
if len(fp_m) != 1 or len(fj_m) != 2 or len(cl_m) != 2:
    _warn += 1
    print("  !! 警告: 标题字符串出现次数异常 (功能面板=%d 文件管理=%d 网络存储=%d), 跳过导航重排"
          % (len(fp_m), len(fj_m), len(cl_m)))
else:
    fp = fp_m[0]

    # 定位 功能面板 标题块：向左找最近的 new-instance Lt9/h3，向右找 <init> 与 add
    sv = fp.group(1)
    prefix = c[:fp.start()]
    tcm = list(TC_RE.finditer(prefix))
    if not tcm:
        _warn += 1
        print("  !! 警告: 未找到功能面板标题 new-instance")
    else:
        tv = tcm[-1].group(1)
        tcls = 'Lt9/h3;'
        after_fp = c[fp.start():fp.start() + 300]
        m_dir = re.search(r'invoke-direct\s+\{' + re.escape(tv) + r',\s*' + re.escape(sv) + r',\s*(v\d+)\},\s*' + re.escape(tcls) + r'-><init>\(Ljava/lang/String;Z\)V', after_fp)
        m_add = re.search(r'invoke-virtual\s+\{(v\d+),\s*' + re.escape(tv) + r'\},\s*Ljava/util/ArrayList;->add\(Ljava/lang/Object;\)Z', after_fp)
        if m_dir is None or m_add is None:
            _warn += 1
            print("  !! 警告: 未提取到功能面板标题块寄存器")
        else:
            bv = m_dir.group(1)
            av = m_add.group(1)
            # 功能面板 new-instance 的起始位置（插入点之前）
            fp_new_inst_start = tcm[-1].start()

            # 2a) 功能面板默认选中 const/4 <bv>, 0x1 改为 0x0
            fp_true = re.search(r'const/4\s+' + re.escape(bv) + r',\s*0x1', after_fp)
            if fp_true:
                pos = fp.start() + fp_true.start()
                c = c[:pos] + ('const/4 ' + bv + ', 0x0') + c[fp.start() + fp_true.end():]
            else:
                _warn += 1
                print("  !! 警告: 未找到功能面板默认选中标记")

            # 2b) 在 功能面板 标题块前插入 应用商店(默认选中) 标题
            def mk_title(reg_pair, name, selected):
                return ("    new-instance " + tv + ", " + tcls + "\n\n"
                        "    const-string " + sv + ", \"" + name + "\"\n\n"
                        "    const/4 " + bv + ", " + ("0x1" if selected else "0x0") + "\n\n"
                        "    invoke-direct {" + tv + ", " + sv + ", " + bv + "}, " + tcls + "-><init>(Ljava/lang/String;Z)V\n\n"
                        "    invoke-virtual {" + av + ", " + tv + "}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z\n\n")

            ins_titles = mk_title(tv, "\\u5e94\\u7528\\u5546\\u5e97", True)
            # 重新计算 fp_new_inst_start（因为修改 selected 可能改变了字符串长度）
            # 重新搜索 功能面板
            fp_new = re.search(FUNCPANEL, c)
            if fp_new:
                prefix_new = c[:fp_new.start()]
                tcm_new = list(TC_RE.finditer(prefix_new))
                if tcm_new:
                    fp_new_inst_start = tcm_new[-1].start()
            c = c[:fp_new_inst_start] + "\n    # Add app-store tab (before func-panel)\n" + ins_titles + c[fp_new_inst_start:]
            modified = True
            print("  ActivityHome.smali: 已插入 应用商店 标题 (应用商店默认选中, 排在功能面板前)")

            # 3) Fragment 列表: 在原 功能面板 Fragment 之前插入 AppStoreFragment
            #    标题顺序: 应用商店(0) -> 功能面板(1)
            #    Fragment 顺序: AppStoreFragment(0) -> 功能面板原始Fragment(1)
            frag_list = re.search(r'new-instance\s+(v\d+),\s*Ljava/util/ArrayList;', c)
            if frag_list is None:
                _warn += 1
                print("  !! 警告: 未找到 Fragment 列表结构")
            else:
                fav = frag_list.group(1)
                after2 = c[frag_list.end():]
                frag_first = re.search(r'new-instance\s+(v\d+),\s*((?!Ljava/util/ArrayList;)L[^;\s]+;)', after2)
                if frag_first is None:
                    _warn += 1
                    print("  !! 警告: 未找到第一个 Fragment 项")
                else:
                    fv = frag_first.group(1)
                    # 第一个 Fragment (pa/u7) 的 new-instance 起始位置
                    frag_start = frag_list.end() + frag_first.start()
                    frags = ("    # Add AppStoreFragment (before func-panel fragment)\n"
                             "    new-instance " + fv + ", Lcom/appstore/AppStoreFragment;\n\n"
                             "    invoke-direct {" + fv + "}, Lcom/appstore/AppStoreFragment;-><init>()V\n\n"
                             "    invoke-virtual {" + fav + ", " + fv + "}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z\n\n")
                    c = c[:frag_start] + frags + c[frag_start:]
                    modified = True
                    print("  ActivityHome.smali: 已在功能面板 Fragment 之前插入 AppStoreFragment")

            # 4) ViewPager 初始页保持 index 0 (原版默认就是 0, 重排后 0 = 应用商店)
            #    无需修改 ViewPager 初始页
            print("  ActivityHome.smali: ViewPager 初始页保持 0 (应用商店)")

with open(ah, 'w') as f:
    f.write(c)
if modified:
    print("  ActivityHome.smali: 导航重排注入完成")
else:
    print("  ActivityHome.smali: 未做任何修改 (请检查锚点)")
PYEOF
else
    echo "  !! 警告: ActivityHome.smali 未找到, 跳过注入"
fi

echo "应用商店入口注入完成。"

# ===== Step 4.6: 注入激活界面资源 + 重映射更新对话框资源 ID =====
echo "=== Step 4.6: 注入激活界面资源 + 重映射更新对话框资源 ID ==="
# 4.6a. 复制激活界面依赖的 drawable (activation_qr / activation_icon) 到目标 APK
#       AppStoreFragment.showLicenseView 用 getIdentifier 按名查找, 资源存在即显示
RES_DST="$GONGQIAN/res/drawable"
mkdir -p "$RES_DST"
for img in activation_qr.png activation_icon.png; do
    if [ -f "$WORK/assets/$img" ]; then
        cp "$WORK/assets/$img" "$RES_DST/$img"
        echo "  已注入资源: $img"
    else
        echo "  !! 警告: assets/$img 不存在, 跳过"
    fi
done

# 4.6a2. 复制 AppStoreFragment 主布局 fragment_appstore.xml 到目标 APK
#       新版应用管家 APK 缺失该布局, onCreateView inflate LAYOUT_ID 会闪退
LAYOUT_SRC="$WORK/assets/res/layout/fragment_appstore.xml"
LAYOUT_DST="$GONGQIAN/res/layout"
if [ -f "$LAYOUT_SRC" ]; then
    mkdir -p "$LAYOUT_DST"
    cp "$LAYOUT_SRC" "$LAYOUT_DST/fragment_appstore.xml"
    echo "  已注入布局: fragment_appstore.xml"
else
    echo "  !! 警告: assets/res/layout/fragment_appstore.xml 不存在, 跳过"
fi

# 4.6b. 重映射 AppStoreFragment.smali 中硬编码的资源 ID
#       YYGJ 编译时的 ID 与目标 APK 不一致, 需按 public.xml 名字面动态解析
APPSTORE_SMALI="$GONGQIAN/smali_classes2/com/appstore/AppStoreFragment.smali"
PUBLIC_XML="$GONGQIAN/res/values/public.xml"
if [ -f "$APPSTORE_SMALI" ] && [ -f "$PUBLIC_XML" ]; then
    python3 "$WORK/remap_resids.py" "$PUBLIC_XML" "$APPSTORE_SMALI" || true
else
    echo "  !! 警告: AppStoreFragment.smali 或 public.xml 未找到, 跳过资源 ID 重映射"
fi

echo "激活界面资源注入完成。"

# ===== Step 4.5e: 修复功能面板版本信息显示 =====
# 问题: 后台线程发送 0x7b 消息触发 q() 更新版本信息, 但此时 Fragment 的 k() 尚未执行,
#        TextView (j) 为 null, 导致版本信息无法显示。
# 修复: 1. 在 k() 方法末尾调用 q(), 确保视图创建后立即填充版本信息
#        2. 在 q() 方法开头添加 null 检查, 防止 TextView 未初始化时崩溃
echo "=== Step 4.5e: 修复功能面板版本信息显示 ==="
if [ -f "$WORK/fix_version_display.py" ]; then
    python3 "$WORK/fix_version_display.py" "$GONGQIAN"
else
    echo "  !! 警告: fix_version_display.py 未找到, 跳过版本信息修复"
fi
echo "版本信息显示修复完成。"

# ===== Step 5: 用 apktool 重新打包 APK =====
echo "=== Step 5: 重新打包 APK ==="
rm -f "$WORK/gongqian_appstore.apk"
java -jar "$TOOLS/apktool.jar" b "$GONGQIAN" -o "$WORK/gongqian_appstore.apk" --use-aapt2 2>&1

echo "APK 打包完成。"

# ===== Step 6: Zipalign =====
echo "=== Step 6: Zipalign ==="
ZIPALIGN="$TOOLS/zipalign"
if [ ! -f "$ZIPALIGN" ]; then
    echo "跳过 zipalign（工具未找到）"
else
    # zipalign 依赖 libc++.so，收集 tools 下所有 lib64 目录
    NATIVE_LIBS="$TOOLS/lib64"
    for d in "$TOOLS"/android-*/lib64; do
        if [ -d "$d" ]; then
            NATIVE_LIBS="$d:$NATIVE_LIBS"
        fi
    done
    export LD_LIBRARY_PATH="$NATIVE_LIBS${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
    "$ZIPALIGN" -f -p 4 "$WORK/gongqian_appstore.apk" "$WORK/gongqian_appstore_aligned.apk" 2>&1
    cp "$WORK/gongqian_appstore_aligned.apk" "$WORK/gongqian_appstore.apk"
fi

# ===== Step 7: 签名 =====
echo "=== Step 7: 签名 ==="
APKSIGNER="$TOOLS/apksigner"
APKSIGNER_JAR="$TOOLS/apksigner.jar"

if [ -f "$APKSIGNER" ]; then
    "$APKSIGNER" sign \
        --key "$WORK/platform.pk8" \
        --cert "$WORK/platform.x509.pem" \
        --out "$WORK/gongqian_appstore_signed.apk" \
        "$WORK/gongqian_appstore.apk" 2>&1
elif [ -f "$APKSIGNER_JAR" ]; then
    java -jar "$APKSIGNER_JAR" sign \
        --key "$WORK/platform.pk8" \
        --cert "$WORK/platform.x509.pem" \
        --out "$WORK/gongqian_appstore_signed.apk" \
        "$WORK/gongqian_appstore.apk" 2>&1
else
    # 使用 jarsigner 作为后备
    echo "使用 jarsigner 签名..."
    cp "$WORK/gongqian_appstore.apk" "$WORK/gongqian_appstore_signed.apk"
    jarsigner -keystore /dev/null -storepass "" "$WORK/gongqian_appstore_signed.apk" dummy 2>/dev/null || \
    echo "警告：无法签名，请手动签名"
fi

# ===== Step 8: 验证签名 =====
echo "=== Step 8: 验证 ==="
if [ -f "$APKSIGNER" ]; then
    "$APKSIGNER" verify --verbose "$WORK/gongqian_appstore_signed.apk" 2>&1
elif [ -f "$APKSIGNER_JAR" ]; then
    java -jar "$APKSIGNER_JAR" verify --verbose "$WORK/gongqian_appstore_signed.apk" 2>&1
fi

echo ""
echo "=== 编译完成！==="
ls -la "$WORK/gongqian_appstore_signed.apk"
