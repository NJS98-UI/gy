.class public Lcom/mcity/cjzs/ui/AppStorePage;
.super Lw6/g;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Lw6/g;-><init>()V

    return-void
.end method


# virtual methods
.method public final j()I
    .locals 1

    .line 1
    const v0, 0x7f0c00be

    return v0
.end method

.method public final k()V
    .locals 5

    .line 1
    new-instance v0, Lcom/appstore/AppStoreFragment;

    invoke-direct {v0}, Lcom/appstore/AppStoreFragment;-><init>()V

    .line 2
    iget-object v1, p0, Lw6/g;->e:Landroid/content/Context;

    iput-object v1, v0, Lcom/appstore/AppStoreFragment;->e:Landroid/content/Context;

    .line 3
    iget-object v1, p0, Lw6/g;->f:Landroid/app/Activity;

    iput-object v1, v0, Lcom/appstore/AppStoreFragment;->f:Landroid/app/Activity;

    .line 4
    invoke-virtual {v0}, Lcom/appstore/AppStoreFragment;->k()V

    .line 5
    iget-object v1, v0, Lcom/appstore/AppStoreFragment;->a:Landroid/view/View;

    if-nez v1, :cond_0

    return-void

    .line 6
    :cond_0
    iget-object v2, p0, Lw6/g;->a:Landroid/view/View;

    check-cast v2, Landroid/view/ViewGroup;

    invoke-virtual {v2}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 7
    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v3, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method