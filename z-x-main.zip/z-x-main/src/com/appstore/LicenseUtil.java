package com.appstore;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

public class LicenseUtil {

    private static final String APP_PHP_URL = "https://app.ahcjzs.cn/app.php";
    private static final String APP_BASE_URL = "https://app.ahcjzs.cn";

    // 原始 APK 使用 config.json 存储, 保持兼容
    private static final String CONFIG_FILE = "config.json";
    private static final String KEY_APPS_COOKIE = "appsCookie";
    private static final String KEY_APPS_PASSWORD = "appsPassword";

    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36";
    private static final int CONNECT_TIMEOUT_MS = 30000;
    private static final int READ_TIMEOUT_MS = 30000;

    private LicenseUtil() {}

    public static class ActivateResult {
        public boolean success;
        public String message;
    }

    public static class AppInfo {
        public String name;
        public String version;
        public String description;
        public String type;
        public String beizhu;
        public String icon;
        public String url;
    }

    public static class AppListResult {
        public boolean ok;
        public boolean expired;
        public List<AppInfo> apps;
    }

    // 激活码激活：先 GET app.php 拿 uuid，再 POST 激活码验证。
    public static ActivateResult activate(Context ctx, String cardCode) {
        ActivateResult r = new ActivateResult();
        if (cardCode == null || cardCode.trim().isEmpty()) {
            r.success = false;
            r.message = "\u8bf7\u8f93\u5165\u6fc0\u6d3b\u7801";
            return r;
        }
        // getUuid() 返回 appsCookie 的原始值，原版格式为 "user_uuid=<uuid>"
        String cookieStr = getUuid(ctx);
        String rawUuid;
        if (cookieStr == null || cookieStr.isEmpty()) {
            // 首次激活：从服务器获取 UUID
            rawUuid = fetchUuid();
            if (rawUuid == null || rawUuid.isEmpty()) {
                r.success = false;
                r.message = "\u5931\u8d25\uff1a\u8bf7\u786e\u4fdd\u5df2\u7ecf\u8054\u7f51";
                return r;
            }
            cookieStr = "user_uuid=" + rawUuid;
        } else {
            // 已有 UUID：从 cookie 字符串中提取纯 UUID
            rawUuid = extractRawUuid(cookieStr);
            if (rawUuid == null || rawUuid.isEmpty()) {
                r.success = false;
                r.message = "\u5931\u8d25\uff1a\u8bf7\u786e\u4fdd\u5df2\u7ecf\u8054\u7f51";
                return r;
            }
        }
        String html = postActivate(cookieStr, rawUuid, cardCode.trim());
        if (html == null) {
            r.success = false;
            r.message = "\u5931\u8d25\uff1a\u8bf7\u786e\u4fdd\u5df2\u7ecf\u8054\u7f51";
            return r;
        }
        if (html.contains("app-description")) {
            // 保存到 config.json, 与原始 APK 一致：appsCookie = "user_uuid=<uuid>"
            saveToConfig(ctx, cookieStr, cardCode.trim());
            r.success = true;
            r.message = "\u6fc0\u6d3b\u6210\u529f";
        } else {
            String err = extract(html, "<h3>", "</h3>");
            r.success = false;
            r.message = (err == null || err.isEmpty()) ? "\u5931\u8d25\uff1a\u8bf7\u786e\u4fdd\u5df2\u7ecf\u8054\u7f51" : err;
        }
        return r;
    }

    // 拉取应用列表：GET app.php 带 Cookie，判断下载权限并解析。
    public static AppListResult fetchAppList(Context ctx) {
        AppListResult r = new AppListResult();
        // getUuid() 返回 appsCookie 的原始值，原版格式为 "user_uuid=<uuid>"，直接用作 Cookie
        String cookie = getUuid(ctx);
        if (cookie == null || cookie.isEmpty()) {
            r.ok = false;
            r.expired = true;
            return r;
        }
        String html = httpGet(APP_PHP_URL, cookie, APP_PHP_URL);
        if (html == null) {
            r.ok = false;
            r.expired = false;
            return r;
        }
        if (html.contains("download-button")) {
            r.ok = true;
            r.expired = false;
            r.apps = parseAppList(html);
        } else if (html.contains("\u8bf7\u8f93\u5165\u5361\u5bc6") || html.contains("\u8bf7\u8f93\u5165\u6fc0\u6d3b\u7801")) {
            r.ok = false;
            r.expired = true;
        } else {
            r.ok = false;
            r.expired = false;
        }
        return r;
    }

    // 解析 app.php 返回的 HTML 应用卡片列表。
    public static List<AppInfo> parseAppList(String html) {
        List<AppInfo> list = new ArrayList<AppInfo>();
        if (html == null || html.isEmpty()) return list;
        String script = extract(html, "<script>", "</script>");
        List<String> cards = splitCards(html);
        for (String card : cards) {
            AppInfo info = new AppInfo();
            info.name = extract(card, "<div class=\"app-name\">", "</div>");
            info.version = extract(card, "<div class=\"app-version\">", "</div>");
            info.description = extract(card, "<div class=\"app-description\">", "</div>");
            if (info.description != null) {
                info.description = info.description.replace("<br>", "\n").replace("</br>", "\n");
            }
            info.type = extract(card, "<div class=\"app-type\">", "</div>");
            info.beizhu = extract(card, "<div class=\"app-beizhu\">", "</div>");
            info.icon = resolveUrl(extract(card, "<img src=\"", "\""));
            if (card.contains("window.location.href = '")) {
                info.url = resolveUrl(extract(card, "window.location.href = '", "'"));
            } else {
                String onclick = extract(card, "onclick=\"", "\"");
                if (onclick != null && !onclick.isEmpty() && script != null) {
                    String funcBody = extract(script, onclick, "}");
                    info.url = resolveUrl(extract(funcBody, "var text = '", "'"));
                }
            }
            if (info.name != null && !info.name.isEmpty()) {
                list.add(info);
            }
        }
        return list;
    }

    // ===== config.json 读写方法 (与原始 APK 完全一致) =====

    // 从 config.json 读取 appsCookie (原版格式为 "user_uuid=<uuid>"，直接用作 Cookie 头)
    public static String getUuid(Context ctx) {
        if (ctx == null) return null;
        try {
            File f = new File(ctx.getFilesDir(), CONFIG_FILE);
            if (!f.exists()) return null;
            StringBuilder sb = new StringBuilder();
            BufferedReader reader = new BufferedReader(new FileReader(f));
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            reader.close();
            String json = sb.toString();
            if (json.isEmpty()) return null;
            JSONObject obj = new JSONObject(json);
            String cookie = obj.optString(KEY_APPS_COOKIE, "");
            return (cookie == null || cookie.isEmpty()) ? null : cookie;
        } catch (Exception e) {
            return null;
        }
    }

    // 从 appsCookie 值中提取纯 UUID（兼容 "user_uuid=<uuid>" 和纯 UUID 两种格式）
    private static String extractRawUuid(String cookieStr) {
        if (cookieStr == null || cookieStr.isEmpty()) return null;
        if (cookieStr.startsWith("user_uuid=")) {
            return cookieStr.substring("user_uuid=".length());
        }
        return cookieStr;
    }

    // 从 config.json 读取 appsPassword (即激活码)，用于过期后预填输入框（与原版一致）
    public static String getStoredPassword(Context ctx) {
        if (ctx == null) return null;
        try {
            File f = new File(ctx.getFilesDir(), CONFIG_FILE);
            if (!f.exists()) return null;
            StringBuilder sb = new StringBuilder();
            BufferedReader reader = new BufferedReader(new FileReader(f));
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            reader.close();
            String json = sb.toString();
            if (json.isEmpty()) return null;
            JSONObject obj = new JSONObject(json);
            String pwd = obj.optString(KEY_APPS_PASSWORD, "");
            return (pwd == null || pwd.isEmpty()) ? null : pwd;
        } catch (Exception e) {
            return null;
        }
    }

    // 保存 Cookie 到 config.json
    public static void saveUuid(Context ctx, String cookieStr) {
        saveToConfig(ctx, cookieStr, null);
    }

    // 保存 Cookie 和激活码到 config.json (与原始 APK 的 a0.g() 一致)
    // cookieStr 格式为 "user_uuid=<uuid>"，与原版存储格式完全一致
    private static void saveToConfig(Context ctx, String cookieStr, String password) {
        if (ctx == null || cookieStr == null || cookieStr.isEmpty()) return;
        try {
            File f = new File(ctx.getFilesDir(), CONFIG_FILE);
            // 读取现有 config.json
            JSONObject obj;
            if (f.exists()) {
                StringBuilder sb = new StringBuilder();
                BufferedReader reader = new BufferedReader(new FileReader(f));
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                reader.close();
                String content = sb.toString();
                if (!content.isEmpty()) {
                    obj = new JSONObject(content);
                } else {
                    obj = new JSONObject();
                }
            } else {
                f.getParentFile().mkdirs();
                obj = new JSONObject();
            }
            // 写入 appsCookie (完整 Cookie 字符串 "user_uuid=<uuid>"，与原版一致)
            obj.put(KEY_APPS_COOKIE, cookieStr);
            // 写入 appsPassword (激活码), 如果提供了的话
            if (password != null && !password.isEmpty()) {
                obj.put(KEY_APPS_PASSWORD, password);
            }
            // 写回文件
            FileWriter writer = new FileWriter(f);
            writer.write(obj.toString());
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void clearUuid(Context ctx) {
        if (ctx == null) return;
        try {
            File f = new File(ctx.getFilesDir(), CONFIG_FILE);
            if (!f.exists()) return;
            StringBuilder sb = new StringBuilder();
            BufferedReader reader = new BufferedReader(new FileReader(f));
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            reader.close();
            JSONObject obj = new JSONObject(sb.toString());
            obj.remove(KEY_APPS_COOKIE);
            obj.remove(KEY_APPS_PASSWORD);
            FileWriter writer = new FileWriter(f);
            writer.write(obj.toString());
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 首次激活：GET app.php 获取后端生成的 uuid。
    private static String fetchUuid() {
        String html = httpGet(APP_PHP_URL, null, null);
        if (html == null) return null;
        if (!html.contains("uuid")) return null;
        String uuid = extract(html, "name=\"uuid\" value=\"", "\"");
        return (uuid == null || uuid.isEmpty()) ? null : uuid;
    }

    // 提交激活码：POST uuid + page_pwd，Header Cookie 直接使用 appsCookie 的值（与原版一致）。
    private static String postActivate(String cookieStr, String rawUuid, String cardCode) {
        try {
            URL url = new URL(APP_PHP_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            // Cookie 直接使用 appsCookie 的值（原版格式 "user_uuid=<uuid>"）
            conn.setRequestProperty("Cookie", cookieStr);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setDoOutput(true);
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setUseCaches(false);
            conn.setInstanceFollowRedirects(true);
            // POST body 使用纯 UUID
            String body = "uuid=" + URLEncoder.encode(rawUuid, "UTF-8")
                + "&page_pwd=" + URLEncoder.encode(cardCode, "UTF-8");
            OutputStream os = conn.getOutputStream();
            os.write(body.getBytes(StandardCharsets.UTF_8));
            os.flush();
            os.close();
            int code = conn.getResponseCode();
            if (code != 200) {
                conn.disconnect();
                return null;
            }
            String html = readStream(conn.getInputStream());
            conn.disconnect();
            return html;
        } catch (Exception e) {
            return null;
        }
    }

    private static String httpGet(String urlStr, String cookie, String referer) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            if (cookie != null && !cookie.isEmpty()) {
                conn.setRequestProperty("Cookie", cookie);
            }
            if (referer != null && !referer.isEmpty()) {
                conn.setRequestProperty("Referer", referer);
            }
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setUseCaches(false);
            conn.setInstanceFollowRedirects(true);
            int code = conn.getResponseCode();
            if (code != 200) {
                conn.disconnect();
                return null;
            }
            String html = readStream(conn.getInputStream());
            conn.disconnect();
            return html;
        } catch (Exception e) {
            return null;
        }
    }

    private static String extract(String content, String start, String end) {
        if (content == null) return "";
        int i = content.indexOf(start);
        if (i < 0) return "";
        i += start.length();
        int j = content.indexOf(end, i);
        if (j < 0) return "";
        return content.substring(i, j);
    }

    // 按 <div class="app-card"> 到 </button> 分割每个应用卡片。
    private static List<String> splitCards(String html) {
        List<String> list = new ArrayList<String>();
        String marker = "<div class=\"app-card\">";
        String endMarker = "</button>";
        String s = html;
        while (true) {
            int start = s.indexOf(marker);
            if (start < 0) break;
            start += marker.length();
            int end = s.indexOf(endMarker, start);
            if (end < 0) break;
            String card = s.substring(start, end);
            s = s.substring(end + endMarker.length());
            if (card != null && !card.isEmpty()) {
                list.add(card);
            }
            if (s.isEmpty()) break;
        }
        return list;
    }

    private static String resolveUrl(String u) {
        if (u == null || u.isEmpty()) return u;
        if (u.startsWith("http://") || u.startsWith("https://")) return u;
        if (u.startsWith("//")) return "https:" + u;
        if (u.startsWith("/")) return APP_BASE_URL + u;
        return APP_BASE_URL + "/" + u;
    }

    private static String readStream(InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append("\n");
        }
        reader.close();
        return sb.toString();
    }
}
