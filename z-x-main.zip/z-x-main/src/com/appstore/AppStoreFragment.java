package com.appstore;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;
import android.util.LruCache;
import android.util.Base64;
import org.json.JSONObject;

import com.ahcjzs.view.MyProgressViewTest;

import z9.g;

public class AppStoreFragment extends g {

    // === Static icon cache: in-memory only, cleared on process exit (never persisted to disk) ===
    private static LruCache<String, Bitmap> sIconCache = null;
    private static ExecutorService sIconExecutor = null;
    private static javax.net.ssl.SSLSocketFactory sSslFactory = null;
    private static final String ICON_DISK_DIR = "store_icons";

    // 应用上下文，商店自更新检查时使用
    private static volatile android.content.Context sAppContext = null;

    // 宿主 Activity，更新对话框显示时使用（Dialog 需要 Activity 上下文）
    private static volatile android.app.Activity sHostActivity = null;

    // 应用图标兜底地址：图标由 app.php 返回完整 URL，这里仅作相对路径兜底
    private static final String[] ICON_CDNS = {
        "https://app.ahcjzs.cn/"
    };

    // 激活页二维码与文案来源（原版阿辉应用管家）
    private static final String CYN_JSON_URL = "https://app.ahcjzs.cn/cyn.json";

    // LOP 同款：顺序重试，最多 3 次，每次失败间隔 2000ms
    private static final int MAX_RETRIES = 3;
    private static final long RETRY_DELAY_MS = 2000L;

    // LOP 同款传输参数
    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36";
    private static final int CONNECT_TIMEOUT_MS = 30000;
    private static final int READ_TIMEOUT_MS = 30000;

    static {
        if (sIconCache == null) {
            int maxMem = (int) (Runtime.getRuntime().maxMemory() / 8);
            sIconCache = new LruCache<String, Bitmap>(maxMem) {
                @Override
                protected int sizeOf(String key, Bitmap value) {
                    return value.getByteCount();
                }
            };
        }
        if (sIconExecutor == null) {
            sIconExecutor = Executors.newFixedThreadPool(16);
        }
    }

    // Called by ActivityHome.onCreate at app startup. Records the app context
    // for self-update checks, kicks off a background fetch of appstore.json and
    // all app icons, and checks for store updates immediately on launch.
    public static void preload(android.content.Context ctx) {
        if (ctx != null) {
            sAppContext = ctx.getApplicationContext();
            if (ctx instanceof android.app.Activity) {
                sHostActivity = (android.app.Activity) ctx;
            }
        }
        final android.content.Context appCtx = ctx != null ? ctx.getApplicationContext() : null;
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (appCtx == null) return;
                LicenseUtil.AppListResult result = LicenseUtil.fetchAppList(appCtx);
                if (result != null && result.ok && result.apps != null) {
                    preloadIconsStatic(result.apps);
                }
            }
        }).start();
    }

    // Fetch every icon referenced in the given app list into the in-memory LruCache.
    private static void preloadIconsStatic(List<LicenseUtil.AppInfo> apps) {
        try {
            java.util.Set<String> icons = new java.util.HashSet<String>();
            if (apps != null) {
                for (LicenseUtil.AppInfo app : apps) {
                    if (app.icon != null && app.icon.length() > 0) icons.add(app.icon);
                }
            }
            for (final String iconPath : icons) {
                final String cacheKey = iconPath.startsWith("http") ? iconPath : ICON_CDNS[0] + iconPath;
                final String[] urls = buildIconUrls(iconPath);
                sIconExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        if (sIconCache.get(cacheKey) != null) return;
                        byte[] data = fetchIconOnce(cacheKey, urls);
                        if (data == null) return;
                        Bitmap bmp = decodeIconBitmap(data);
                        if (bmp != null) {
                            sIconCache.put(cacheKey, bmp);
                        }
                    }
                });
            }
        } catch (Exception ex) {
        }
    }

    private static javax.net.ssl.SSLSocketFactory getSslFactoryStatic() {
        if (sSslFactory != null) return sSslFactory;
        try {
            javax.net.ssl.TrustManager[] tm = new javax.net.ssl.TrustManager[]{
                new javax.net.ssl.X509TrustManager() {
                    public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {}
                    public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {}
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() { return new java.security.cert.X509Certificate[0]; }
                }
            };
            javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("TLS");
            sc.init(null, tm, new java.security.SecureRandom());
            sSslFactory = sc.getSocketFactory();
            return sSslFactory;
        } catch (Exception e) {
            return null;
        }
    }

    // LOP 同款：给连接加 no-cache 头，绕过 CDN/HTTP 缓存，每次强制回源
    private static void applyNoCacheHeaders(HttpURLConnection conn) {
        conn.setRequestProperty("Cache-Control", "no-cache, no-store");
        conn.setRequestProperty("Pragma", "no-cache");
        conn.setRequestProperty("Connection", "keep-alive");
    }

    // LOP 同款：URL 追加秒级时间戳做缓存破坏，CDN 会视为新请求回源
    private static String addCacheBuster(String url) {
        long t = System.currentTimeMillis() / 1000;
        if (url == null) return url;
        if (url.indexOf('?') >= 0) return url + "&t=" + t;
        return url + "?t=" + t;
    }

    private static String readStreamStatic(InputStream is) throws Exception {
        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int len;
        while ((len = is.read(buf)) != -1) {
            baos.write(buf, 0, len);
        }
        is.close();
        return baos.toString("UTF-8");
    }

    private static byte[] readAllBytesStatic(InputStream is) throws Exception {
        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int len;
        while ((len = is.read(buf)) != -1) {
            baos.write(buf, 0, len);
        }
        return baos.toByteArray();
    }

    private AppGridAdapter adapter;
    private GridView gridView;
    private ListView sidebarList;
    private SidebarAdapter sidebarAdapter;
    private int selectedCategory = 0;
    private boolean inited = false;
    private TextView loadingText;

    private List<CatData> catList = new ArrayList<CatData>();
    private List<AppData> allAppList = new ArrayList<AppData>();
    private List<AppData> filteredAppList = new ArrayList<AppData>();
    private static List<String> downloadProgressKeys = new ArrayList<String>();
    private static List<Integer> downloadProgressValues = new ArrayList<Integer>();
    private static java.lang.ref.WeakReference<AppStoreFragment> sActiveInstance =
        new java.lang.ref.WeakReference<AppStoreFragment>(null);
    private String searchQuery = "";

    private static final int RES_BJ_2 = 0x7f08009b;
    private static final int RES_BJ_WINDOW = 0x7f0800b0;
    private static final int RES_GJ_BANNER = 0x7f08011e;
    private static final int LAYOUT_ID = 0x7f0e0218;

    // === 参考图配色：深蓝紫渐变 + 橙色选中 + 紫色指示器 ===
    private static final int COLOR_ORANGE = 0xFFfdab06;
    private static final int COLOR_PURPLE = 0xFFFF00FF;
    private static final int COLOR_BLUE = 0xFF3B82F6;
    private static final int COLOR_BLUE_DARK = 0xFF2563EB;
    private static final int COLOR_DOWNLOAD_BTN = 0xFF007AFF;
    private static final int COLOR_CARD_BG = 0xCC1E3A5F;
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;
    private static final int COLOR_TEXT_SECONDARY = 0xFF94A3B8;
    private static final int COLOR_TEXT_MUTED = 0xFF64748B;
    private static final int COLOR_BG_START = 0xFF0F172A;
    private static final int COLOR_BG_END = 0xFF1E1B4B;

    // === 激活相关 ===
    private static final String PREFS_NAME = "store_license";
    private static final String KEY_ACTIVATED = "activated";

    public static class CatData {
        public String name;
        public List<AppData> apps = new ArrayList<AppData>();
    }

    public static class AppData {
        public String name;
        public String version;
        public String description;
        public String size;
        public String icon;
        public String url;
        // 下载唯一标识：同名应用靠它区分（取 url；无 url 时退化为 name）
        public String dkey;
        // 云端控制颜色：0表示使用默认值（与原版一致，服务端可下发自定义颜色）
        public int nameColor = 0;       // 应用名称颜色
        public int descColor = 0;       // 说明文字颜色
    }

    @Override
    public int j() {
        return LAYOUT_ID;
    }

    @Override
    public void k() {
        if (inited) return;
        inited = true;

        final Context ctx = e;
        if (ctx == null) return;

        // 记录应用上下文，供商店自更新检查使用（兜底，正常在 preload 已设置）
        sAppContext = ctx.getApplicationContext();
        sHostActivity = f;

        View rootView = a;
        if (rootView == null) return;
        if (!(rootView instanceof android.widget.FrameLayout)) return;
        final android.widget.FrameLayout frame = (android.widget.FrameLayout) rootView;

        final float d = ctx.getResources().getDisplayMetrics().density;

        android.content.SharedPreferences prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        // 检查激活状态：SharedPreferences 或 config.json 中的 UUID 任一存在即视为已激活
        // 这样覆盖安装（原版→公签版）时，config.json 中的 UUID 仍可识别
        String savedUuid = LicenseUtil.getUuid(ctx);
        boolean activated = prefs.getBoolean(KEY_ACTIVATED, false)
                || (savedUuid != null && !savedUuid.isEmpty());
        if (!activated) {
            // UUID 不存在，检查是否有保存的激活码（appsPassword）
            // 如果有，自动尝试重新激活（与原版行为一致：保存的激活码可以重新获取 UUID）
            String savedPwd = LicenseUtil.getStoredPassword(ctx);
            if (savedPwd != null && !savedPwd.isEmpty()) {
                tryAutoActivate(ctx, frame, d, prefs, savedPwd);
                return;
            }
            showLicenseView(ctx, frame, d, prefs);
            return;
        }

        initStoreView(ctx, frame, d);
    }

    // 自动重新激活：UUID 丢失但有保存的激活码时，后台自动激活
    private void tryAutoActivate(final Context ctx, final android.widget.FrameLayout frame,
            final float d, final android.content.SharedPreferences prefs, final String savedPwd) {
        // 显示加载中提示
        frame.removeAllViews();
        LinearLayout loading = new LinearLayout(ctx);
        loading.setOrientation(LinearLayout.VERTICAL);
        loading.setGravity(Gravity.CENTER);
        loading.setBackgroundResource(RES_BJ_WINDOW);
        TextView tvLoading = new TextView(ctx);
        tvLoading.setText("\u6b63\u5728\u9a8c\u8bc1\u6fc0\u6d3b\u7801...");
        tvLoading.setTextColor(0xFFFFFFFF);
        tvLoading.setTextSize(16);
        loading.addView(tvLoading);
        frame.addView(loading, new android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        new Thread(new Runnable() {
            @Override
            public void run() {
                final LicenseUtil.ActivateResult result = LicenseUtil.activate(ctx, savedPwd);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if (result.success) {
                            prefs.edit().putBoolean(KEY_ACTIVATED, true).apply();
                            initStoreView(ctx, frame, d);
                        } else {
                            // 自动激活失败，显示手动激活界面（预填激活码）
                            showLicenseView(ctx, frame, d, prefs);
                        }
                    }
                });
            }
        }).start();
    }

    // ==================== 参考图布局：左侧分类居中 + 右侧3列横向卡片 ====================
    private void initStoreView(Context ctx, android.widget.FrameLayout frame, float d) {
        // === 主容器：透明背景（使用宿主窗口背景）===
        LinearLayout mainLayout = new LinearLayout(ctx);
        mainLayout.setOrientation(LinearLayout.HORIZONTAL);
        mainLayout.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        frame.setBackgroundColor(android.graphics.Color.TRANSPARENT);

        // === 左侧分类导航栏（透明背景）===
        // 分类整体垂直居中：上下弹性空间对称，列表按内容高度；内容过多时内部滚动，选中项居中
        LinearLayout sidebarContainer = new LinearLayout(ctx);
        sidebarContainer.setOrientation(LinearLayout.VERTICAL);
        sidebarContainer.setGravity(Gravity.CENTER_VERTICAL);

        // 顶部弹性空间（与底部对称，实现分类整体居中）
        View topSpacer = new View(ctx);
        sidebarContainer.addView(topSpacer, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // 分类列表（wrap_content 按内容高度，超出侧边栏高度则内部滚动）
        final MaxHeightListView list = new MaxHeightListView(ctx);
        sidebarList = list;
        sidebarList.setVerticalScrollBarEnabled(false);
        sidebarList.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        sidebarList.setSelector(android.R.color.transparent);
        sidebarList.setPadding(0, (int)(10 * d), 0, (int)(10 * d));
        sidebarList.setClipToPadding(false);
        sidebarList.setDivider(null);
        sidebarList.setDividerHeight(0);
        sidebarList.setFocusable(true);
        sidebarList.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);

        sidebarAdapter = new SidebarAdapter(ctx, d);
        sidebarList.setAdapter(sidebarAdapter);

        sidebarList.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                selectCategory(position);
            }
        });

        sidebarContainer.addView(sidebarList, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 底部弹性空间（与顶部对称）
        View bottomSpacer = new View(ctx);
        sidebarContainer.addView(bottomSpacer, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        int sidebarWidth = (int)(100 * d);
        mainLayout.addView(sidebarContainer, new LinearLayout.LayoutParams(
            sidebarWidth, ViewGroup.LayoutParams.MATCH_PARENT));

        // === 右侧内容区 ===
        LinearLayout rightArea = new LinearLayout(ctx);
        rightArea.setOrientation(LinearLayout.VERTICAL);

        // 顶部：加载提示 + 搜索 + 刷新
        LinearLayout headerRow = new LinearLayout(ctx);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        headerRow.setPadding((int)(12 * d), (int)(8 * d), (int)(12 * d), (int)(4 * d));

        loadingText = new TextView(ctx);
        loadingText.setText("\u6b63\u5728\u52a0\u8f7d\u4e2d...");
        loadingText.setTextColor(COLOR_ORANGE);
        loadingText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        loadingText.setGravity(Gravity.CENTER_VERTICAL);
        loadingText.setPadding(0, 0, (int)(8 * d), 0);
        headerRow.addView(loadingText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // 搜索框
        final android.widget.EditText etSearch = new android.widget.EditText(ctx);
        etSearch.setHint("\u5173\u952e\u8bcd\u641c\u7d22");
        etSearch.setHintTextColor(0xFF6B7280);
        etSearch.setTextColor(0xFFFFFFFF);
        etSearch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        etSearch.setGravity(Gravity.CENTER_VERTICAL);
        etSearch.setSingleLine(true);
        etSearch.setPadding((int)(10 * d), (int)(4 * d), (int)(10 * d), (int)(4 * d));
        GradientDrawable searchBg = new GradientDrawable();
        searchBg.setCornerRadius(8 * d);
        searchBg.setColor(0x331E3A5F);
        searchBg.setStroke((int)(1 * d), 0x4460A5FA);
        etSearch.setBackground(searchBg);
        etSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(android.text.Editable s) {
                searchQuery = s.toString().trim();
                applySearchFilter();
            }
        });
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams((int)(160 * d), ViewGroup.LayoutParams.WRAP_CONTENT);
        searchLp.rightMargin = (int)(10 * d);
        headerRow.addView(etSearch, searchLp);

        // 刷新按钮
        TextView btnRefresh = new TextView(ctx);
        btnRefresh.setText("\u5237\u65b0");
        btnRefresh.setTextColor(0xFFFFFFFF);
        btnRefresh.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        btnRefresh.setGravity(Gravity.CENTER);
        btnRefresh.setPadding((int)(16 * d), (int)(6 * d), (int)(16 * d), (int)(6 * d));
        GradientDrawable refreshBg = new GradientDrawable();
        refreshBg.setCornerRadius(8 * d);
        refreshBg.setColor(COLOR_BLUE);
        btnRefresh.setBackground(refreshBg);
        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (loadingText != null) {
                    loadingText.setText("\u91cd\u65b0\u52a0\u8f7d\u4e2d...");
                    loadingText.setVisibility(View.VISIBLE);
                }
                catList.clear();
                allAppList.clear();
                filteredAppList.clear();
                if (adapter != null) adapter.notifyDataSetChanged();
                if (sidebarAdapter != null) sidebarAdapter.notifyDataSetChanged();
                searchQuery = "";
                etSearch.setText("");
                fetchData();
            }
        });
        headerRow.addView(btnRefresh);
        rightArea.addView(headerRow, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // GridView - 3列
        gridView = new GridView(ctx);
        gridView.setNumColumns(3);
        gridView.setPadding((int)(10 * d), (int)(6 * d), (int)(10 * d), (int)(10 * d));
        gridView.setHorizontalSpacing((int)(8 * d));
        gridView.setVerticalSpacing((int)(8 * d));
        gridView.setClipToPadding(true);
        gridView.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        // 防止过度滚动时内容穿透到顶部搜索栏
        gridView.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);
        rightArea.addView(gridView, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        mainLayout.addView(rightArea, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        frame.addView(mainLayout, new android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 布局完成后设置分类列表最大高度（=侧边栏高度）：内容少时整体居中，内容多时内部滚动
        sidebarContainer.post(new Runnable() {
            @Override
            public void run() {
                int h = sidebarContainer.getHeight();
                if (h > 0) list.setMaxHeight(h);
            }
        });

        adapter = new AppGridAdapter(ctx, d);
        gridView.setAdapter(adapter);

        fetchData();

        sActiveInstance = new java.lang.ref.WeakReference<AppStoreFragment>(this);
    }

    // === 激活界面 ===
    private void showLicenseView(final Context ctx, final android.widget.FrameLayout frame,
                                 final float d, final android.content.SharedPreferences prefs) {
        // 根布局：保持原有深色背景
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundResource(RES_BJ_WINDOW);

        // 面板：圆角激活框（白描边）— 宽固定530dp
        final LinearLayout panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setCornerRadius((int)(20 * d));
        panelBg.setColor(0xFF1B4A8A);
        panelBg.setStroke((int)(2 * d), 0x66FFFFFF);
        panel.setBackground(panelBg);
        panel.setPadding((int)(18 * d), (int)(16 * d), (int)(18 * d), (int)(16 * d));
        android.widget.FrameLayout.LayoutParams panelLp = new android.widget.FrameLayout.LayoutParams(
            (int)(530 * d), ViewGroup.LayoutParams.WRAP_CONTENT);
        panelLp.gravity = Gravity.CENTER;

        // === 输入行：标题 + 激活码 + 激活按钮（结构参考原版：标题在输入框左侧）===
        LinearLayout inputRow = new LinearLayout(ctx);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setPadding(0, (int)(14 * d), 0, 0);

        TextView panelTitle = new TextView(ctx);
        panelTitle.setText("\u516c\u7b7e\u901a\u7528\u7248");
        panelTitle.setTextSize(18);
        panelTitle.setTextColor(COLOR_ORANGE);
        panelTitle.setTypeface(Typeface.DEFAULT_BOLD);
        panelTitle.setPadding(0, 0, (int)(10 * d), 0);
        inputRow.addView(panelTitle, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final android.widget.EditText etLicense = new android.widget.EditText(ctx);
        etLicense.setHint("\u8bf7\u8f93\u5165\u6fc0\u6d3b\u7801");
        etLicense.setHintTextColor(0xFF9DB8D9);
        etLicense.setTextColor(0xFF1B4A8A);
        etLicense.setTextSize(14);
        etLicense.setGravity(Gravity.CENTER);
        // 预填已保存的激活码（与原版 U() 方法一致：从 config.json 读取 appsPassword 并填入输入框）
        String storedPwd = LicenseUtil.getStoredPassword(ctx);
        if (storedPwd != null && !storedPwd.isEmpty()) {
            etLicense.setText(storedPwd);
        }
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setCornerRadius((int)(8 * d));
        inputBg.setColor(0xFFFFFFFF);
        inputBg.setStroke(0, 0x00000000);
        etLicense.setBackground(inputBg);
        etLicense.setPadding((int)(12 * d), 0, (int)(12 * d), 0);
        etLicense.setSingleLine(true);
        inputRow.addView(etLicense, new LinearLayout.LayoutParams(
            0, (int)(44 * d), 1f));

        final TextView btnActivate = new TextView(ctx);
        btnActivate.setText("\u6fc0 \u6d3b");
        btnActivate.setTextColor(0xFFFFFFFF);
        btnActivate.setTextSize(16);
        btnActivate.setTypeface(Typeface.DEFAULT_BOLD);
        btnActivate.setGravity(Gravity.CENTER);
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setCornerRadius((int)(8 * d));
        btnBg.setColor(0xFF2E86DE);
        btnActivate.setBackground(btnBg);
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
            (int)(88 * d), (int)(44 * d));
        btnLp.setMargins((int)(10 * d), 0, 0, 0);
        inputRow.addView(btnActivate, btnLp);

        panel.addView(inputRow);

        // === 状态提示 ===
        final TextView tvStatus = new TextView(ctx);
        tvStatus.setTextSize(12);
        tvStatus.setGravity(Gravity.CENTER);
        tvStatus.setPadding(0, (int)(8 * d), 0, 0);
        tvStatus.setVisibility(View.GONE);
        panel.addView(tvStatus);

        // === 横分割线（原版 v_view1）===
        View dividerH = new View(ctx);
        dividerH.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams dividerHLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, (int)(3 * d));
        dividerHLp.setMargins(0, (int)(16 * d), 0, 0);
        panel.addView(dividerH, dividerHLp);

        // === 底部两栏：二维码 + 功能说明 ===
        LinearLayout bottomRow = new LinearLayout(ctx);
        bottomRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomRow.setPadding(0, (int)(14 * d), 0, 0);

        // 左栏：激活码获取（二维码）
        LinearLayout leftCol = new LinearLayout(ctx);
        leftCol.setOrientation(LinearLayout.VERTICAL);
        leftCol.setGravity(Gravity.CENTER_HORIZONTAL);
        leftCol.setPadding(0, 0, (int)(12 * d), 0);

        TextView leftTitle = new TextView(ctx);
        leftTitle.setText("\u4e00\u6b21\u6fc0\u6d3b \u6c38\u4e45\u4f7f\u7528");
        leftTitle.setTextSize(13);
        leftTitle.setTextColor(0xFF8FC7FF);
        leftTitle.setTypeface(Typeface.DEFAULT_BOLD);
        leftTitle.setGravity(Gravity.CENTER);
        leftTitle.setPadding(0, 0, 0, (int)(6 * d));
        leftCol.addView(leftTitle);

        TextView leftHint = new TextView(ctx);
        leftHint.setText("\u8bf7\u626b\u4e0b\u65b9\u4e8c\u7ef4\u7801\u8d2d\u4e70");
        leftHint.setTextSize(11);
        leftHint.setTextColor(0xFFB7D4F5);
        leftHint.setGravity(Gravity.CENTER);
        leftHint.setPadding(0, 0, 0, (int)(6 * d));
        leftCol.addView(leftHint);

        // 二维码区域 — FrameLayout 叠放 QR图片 + 占位文字
        android.widget.FrameLayout qrFrame = new android.widget.FrameLayout(ctx);
        final android.widget.ImageView ivQr = new android.widget.ImageView(ctx);
        GradientDrawable qrBg = new GradientDrawable();
        qrBg.setCornerRadius((int)(8 * d));
        qrBg.setColor(0xFFFFFFFF);
        qrBg.setStroke((int)(1 * d), 0x33FFFFFF);
        ivQr.setBackground(qrBg);
        ivQr.setPadding((int)(6 * d), (int)(6 * d), (int)(6 * d), (int)(6 * d));
        qrFrame.addView(ivQr, new android.widget.FrameLayout.LayoutParams(
            (int)(120 * d), (int)(120 * d)));

        // 占位文字"微信:ahcjzs66" — 无网络时显示在二维码位置（大小不变）
        final TextView wechatText = new TextView(ctx);
        wechatText.setTextSize(13);
        wechatText.setTextColor(0xFFFFA500);
        wechatText.setGravity(Gravity.CENTER);
        GradientDrawable pillBg = new GradientDrawable();
        pillBg.setCornerRadius((int)(16 * d));
        pillBg.setColor(0xFF333333);
        wechatText.setBackground(pillBg);
        wechatText.setPadding((int)(12 * d), (int)(4 * d), (int)(12 * d), (int)(4 * d));
        wechatText.setVisibility(View.GONE);
        android.widget.FrameLayout.LayoutParams placeholderLp = new android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        placeholderLp.gravity = Gravity.CENTER;
        qrFrame.addView(wechatText, placeholderLp);

        leftCol.addView(qrFrame, new LinearLayout.LayoutParams((int)(120 * d), (int)(120 * d)));

        bottomRow.addView(leftCol, new LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.42f));

        // 垂直分割线
        View divider = new View(ctx);
        divider.setBackgroundColor(0xFFFFFFFF);
        bottomRow.addView(divider, new LinearLayout.LayoutParams(
            (int)(3 * d), ViewGroup.LayoutParams.MATCH_PARENT));

        // 右栏：说明文字（与阿辉应用管家激活页一致，联网覆盖；框固定大小，文字多时可上下滑动）
        ScrollView rightScroll = new ScrollView(ctx);
        LinearLayout rightCol = new LinearLayout(ctx);
        rightCol.setOrientation(LinearLayout.VERTICAL);
        rightCol.setPadding((int)(12 * d), 0, 0, 0);

        final TextView ts1 = new TextView(ctx);
        ts1.setTextSize(15);
        ts1.setTextColor(0xFFF7F7F7);
        ts1.setTypeface(Typeface.DEFAULT_BOLD);
        ts1.setGravity(Gravity.CENTER);
        ts1.setPadding(0, (int)(2 * d), 0, (int)(2 * d));
        rightCol.addView(ts1);

        final TextView ts2 = new TextView(ctx);
        ts2.setTextSize(13);
        ts2.setTextColor(0xFF1BFF07);
        ts2.setPadding(0, (int)(2 * d), 0, (int)(2 * d));
        rightCol.addView(ts2);

        final TextView ts3 = new TextView(ctx);
        ts3.setTextSize(13);
        ts3.setTextColor(0xFFFFF25B);
        ts3.setPadding(0, (int)(2 * d), 0, (int)(2 * d));
        rightCol.addView(ts3);

        rightScroll.addView(rightCol);
        bottomRow.addView(rightScroll, new LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.MATCH_PARENT, 0.58f));

        panel.addView(bottomRow);

        loadActivationContent(ctx, ivQr, ts1, ts2, ts3, wechatText);

        // === 激活按钮逻辑 ===
        btnActivate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = etLicense.getText().toString().trim();
                if (code.isEmpty()) {
                    Toast.makeText(ctx, "\u672a\u8f93\u5165\u6fc0\u6d3b\u7801", Toast.LENGTH_SHORT).show();
                    return;
                }
                tvStatus.setText("\u6fc0\u6d3b\u4e2d...");
                tvStatus.setTextColor(0xFFFFA500);
                tvStatus.setVisibility(View.VISIBLE);
                btnActivate.setEnabled(false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final LicenseUtil.ActivateResult result = LicenseUtil.activate(ctx, code);
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                btnActivate.setEnabled(true);
                                if (result != null && result.success) {
                                    tvStatus.setText("\u6fc0\u6d3b\u6210\u529f");
                                    tvStatus.setTextColor(0xFF00FF00);
                                    prefs.edit().putBoolean(KEY_ACTIVATED, true).apply();
                                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            frame.removeAllViews();
                                            initStoreView(ctx, frame, d);
                                        }
                                    }, 500);
                                } else {
                                    String msg = (result != null && result.message != null && !result.message.isEmpty())
                                        ? result.message : "\u6fc0\u6d3b\u5931\u8d25";
                                    tvStatus.setText(msg);
                                    tvStatus.setTextColor(0xFFFF4444);
                                }
                            }
                        });
                    }
                }).start();
            }
        });

        root.addView(panel, panelLp);

        frame.addView(root, new android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // 联网加载激活页二维码与文案（原版阿辉应用管家：app.ahcjzs.cn/cyn.json）。
    // 与原版 r5/x.smali h() 方法一致：从 text_sections 数组解析 size、color、text 三个字段，
    // 动态应用到 ts1/ts2/ts3 的文字大小、颜色和内容。
    private void loadActivationContent(final Context ctx, final ImageView ivQr,
                                       final TextView ts1, final TextView ts2, final TextView ts3,
                                       final TextView wechatText) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String jsonText = fetchText(CYN_JSON_URL);
                    if (jsonText == null || jsonText.trim().isEmpty()) {
                        showFetchFailed(ivQr, ts1, ts2, ts3, wechatText);
                        return;
                    }
                    JSONObject obj = new JSONObject(jsonText);
                    String imageUrl = obj.optString("image_url", "");
                    final byte[] qrData = imageUrl.length() > 0 ? fetchBinary(imageUrl) : null;
                    org.json.JSONArray sections = obj.optJSONArray("text_sections");

                    final String[] texts = new String[3];
                    final float[] sizes = new float[3];
                    final int[] colors = new int[3];
                    java.util.Arrays.fill(colors, -1);

                    if (sections != null) {
                        int n = Math.min(sections.length(), 3);
                        for (int i = 0; i < n; i++) {
                            org.json.JSONObject sec = sections.optJSONObject(i);
                            if (sec != null) {
                                String t = sec.optString("text", "");
                                texts[i] = t.trim();
                                try {
                                    String sizeStr = sec.optString("size", "");
                                    if (!sizeStr.isEmpty()) {
                                        sizeStr = sizeStr.toLowerCase().replace("px", "").replace("sp", "").trim();
                                        sizes[i] = Float.parseFloat(sizeStr);
                                    }
                                } catch (Exception e) {}
                                try {
                                    String colorStr = sec.optString("color", "");
                                    if (!colorStr.isEmpty()) {
                                        if (!colorStr.startsWith("#")) colorStr = "#" + colorStr;
                                        colors[i] = android.graphics.Color.parseColor(colorStr);
                                    }
                                } catch (Exception e) {}
                            }
                        }
                    }
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            if (qrData != null) {
                                Bitmap bmp = BitmapFactory.decodeByteArray(qrData, 0, qrData.length);
                                if (bmp != null) ivQr.setImageBitmap(bmp);
                            }
                            TextView[] tvs = {ts1, ts2, ts3};
                            for (int i = 0; i < 3; i++) {
                                if (texts[i] != null && texts[i].length() > 0) tvs[i].setText(texts[i]);
                                if (sizes[i] > 0) tvs[i].setTextSize(sizes[i]);
                                if (colors[i] != -1) tvs[i].setTextColor(colors[i]);
                            }
                            ivQr.setVisibility(View.VISIBLE);
                            wechatText.setVisibility(View.GONE);
                        }
                    });
                } catch (Exception ex) {
                    showFetchFailed(ivQr, ts1, ts2, ts3, wechatText);
                }
            }
        }).start();
    }

    // 与原始APK r5/x.smali 的 f() 方法一致：获取失败时显示错误提示
    private void showFetchFailed(final ImageView ivQr, final TextView ts1, final TextView ts2, final TextView ts3, final TextView wechatText) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                // 无网络时：隐藏二维码，显示"微信:ahcjzs66"占位（同一位置，框大小不变）
                ivQr.setVisibility(View.INVISIBLE);
                wechatText.setVisibility(View.VISIBLE);
                // 错误提示拆成三段，与有网络时文字量一致，框大小不变
                ts1.setText("\u3010 \u963f\u8f89\u5e94\u7528\u7ba1\u5bb6 \u3011");
                ts2.setText("\u4e8c\u7ef4\u7801\u53ca\u4fe1\u606f\u5217\u8868\u83b7\u53d6\u5931\u8d25\uff01\n\u8bf7\u5c1d\u8bd5\u91cd\u65b0\u542f\u52a8\u83b7\u53d6 \u6216\u624b\u52a8\u6dfb\u52a0");
                ts3.setText("\u5ba2\u670d\u5fae\u4fe1 : ahcjzs66");
                wechatText.setText("\u5fae\u4fe1 : ahcjzs66");
            }
        });
    }

    private static String fetchText(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if (conn instanceof javax.net.ssl.HttpsURLConnection) {
                ((javax.net.ssl.HttpsURLConnection) conn).setSSLSocketFactory(getSslFactoryStatic());
            }
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setUseCaches(false);
            conn.setInstanceFollowRedirects(true);
            if (conn.getResponseCode() == 200) {
                String s = readStreamStatic(conn.getInputStream());
                conn.disconnect();
                return s;
            }
            conn.disconnect();
        } catch (Exception e) {
        }
        return null;
    }

    private static byte[] fetchBinary(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if (conn instanceof javax.net.ssl.HttpsURLConnection) {
                ((javax.net.ssl.HttpsURLConnection) conn).setSSLSocketFactory(getSslFactoryStatic());
            }
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setUseCaches(false);
            conn.setInstanceFollowRedirects(true);
            if (conn.getResponseCode() == 200) {
                byte[] data = readAllBytesStatic(conn.getInputStream());
                conn.disconnect();
                return data;
            }
            conn.disconnect();
        } catch (Exception e) {
        }
        return null;
    }

    // ==================== 参考图布局：侧边栏 Adapter（分类文字居中）====================

    // 限高 ListView：content 高度不超过 maxHeight，超出则内部滚动。
    // 用于实现"分类整体垂直居中 + 内容过多时选中项居中滚动"的原版 TvRecyclerView 效果。
    private static class MaxHeightListView extends ListView {
        private int maxHeight = Integer.MAX_VALUE;

        MaxHeightListView(Context ctx) { super(ctx); }

        void setMaxHeight(int h) {
            maxHeight = h;
            requestLayout();
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            if (maxHeight != Integer.MAX_VALUE) {
                int mode = MeasureSpec.getMode(heightMeasureSpec);
                int size = MeasureSpec.getSize(heightMeasureSpec);
                if (mode == MeasureSpec.UNSPECIFIED || size > maxHeight) {
                    heightMeasureSpec = MeasureSpec.makeMeasureSpec(maxHeight, MeasureSpec.AT_MOST);
                }
            }
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        }
    }

    private class SidebarAdapter extends BaseAdapter {
        private Context ctx;
        private float density;

        SidebarAdapter(Context ctx, float d) {
            this.ctx = ctx;
            this.density = d;
        }

        @Override
        public int getCount() { return catList.size(); }

        @Override
        public Object getItem(int position) { return catList.get(position); }

        @Override
        public long getItemId(int position) { return (long) position; }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            CatData cat = (CatData) catList.get(position);
            boolean isSelected = (position == selectedCategory);

            // === 分类项：FrameLayout 叠放文字居中 + 指示条靠右 ===
            // 协调尺寸：与原版TvRecyclerView一致，大屏小屏都用固定dp，视觉协调
            android.widget.FrameLayout rootFrame = new android.widget.FrameLayout(ctx);
            rootFrame.setFocusable(true);
            rootFrame.setClickable(true);
            rootFrame.setMinimumHeight((int)(40 * density));
            rootFrame.setPadding(0, (int)(3 * density), 0, (int)(3 * density));

            // === 分类名称（居中）===
            TextView name = new TextView(ctx);
            name.setText(cat.name);
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER);
            name.setTypeface(isSelected ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            if (isSelected) {
                name.setTextColor(COLOR_ORANGE);
            } else {
                name.setTextColor(Color.WHITE);
            }
            rootFrame.addView(name, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

            // === 右侧紫色竖线指示器（选中时显示）===
            int indicatorWidth = (int)(4 * density);
            android.widget.FrameLayout.LayoutParams indLp = new android.widget.FrameLayout.LayoutParams(
                indicatorWidth, (int)(24 * density));
            indLp.gravity = Gravity.CENTER_VERTICAL | Gravity.RIGHT;
            indLp.rightMargin = (int)(6 * density);
            View indView = new View(ctx);
            if (isSelected) {
                GradientDrawable indShape = new GradientDrawable();
                indShape.setCornerRadius((int)(2 * density));
                indShape.setColor(COLOR_PURPLE);
                indView.setBackground(indShape);
            } else {
                indView.setBackgroundColor(0x00000000);
            }
            rootFrame.addView(indView, indLp);

            rootFrame.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectCategory(position);
                }
            });

            rootFrame.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        v.setBackgroundColor(0x33A855F7);
                    } else {
                        v.setBackgroundColor(0x00000000);
                    }
                }
            });

            return rootFrame;
        }
    }

    private void selectCategory(int idx) {
        if (idx < 0 || idx >= catList.size()) return;
        selectedCategory = idx;
        searchQuery = "";
        sidebarList.setItemChecked(idx, true);
        sidebarAdapter.notifyDataSetChanged();
        filterByCategory();

        // === 选中项居中：内容过多需要滚动时，让选中项保持在可见区域中间（模拟原版TvRecyclerView）===
        sidebarList.post(new Runnable() {
            @Override
            public void run() {
                int listHeight = sidebarList.getHeight();
                if (listHeight <= 0) return;
                float dens = sidebarList.getContext().getResources().getDisplayMetrics().density;
                // 估算全部内容高度：每项40dp最小高度 + 上下6dp内边距，再加列表20dp上下padding
                int estContentH = (int)(46 * dens * catList.size()) + (int)(20 * dens);
                if (estContentH <= listHeight) {
                    // 内容全部可见：由上下弹性空间负责整体居中，无需滚动
                    return;
                }
                View item = sidebarList.getChildAt(idx - sidebarList.getFirstVisiblePosition());
                int itemHeight = (item != null) ? item.getHeight() : (int)(40 * dens);
                int topOffset = (listHeight - itemHeight) / 2;
                if (topOffset < 0) topOffset = 0;
                sidebarList.setSelectionFromTop(idx, topOffset);
            }
        });
    }

    private void filterByCategory() {
        filteredAppList.clear();
        if (selectedCategory < 0 || selectedCategory >= catList.size()) return;

        CatData cat = (CatData) catList.get(selectedCategory);
        for (int i = 0; i < cat.apps.size(); i++) {
            filteredAppList.add(cat.apps.get(i));
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    // 全分类搜索：搜索所有分类内的应用，搜索非空时忽略当前分类
    private void applySearchFilter() {
        filteredAppList.clear();
        String q = searchQuery == null ? "" : searchQuery.toLowerCase().trim();
        if (q.length() == 0) {
            filterByCategory();
            return;
        }
        for (int i = 0; i < allAppList.size(); i++) {
            AppData app = allAppList.get(i);
            boolean match = (app.name != null && app.name.toLowerCase().contains(q))
                || (app.description != null && app.description.toLowerCase().contains(q))
                || (app.version != null && app.version.toLowerCase().contains(q));
            if (match) filteredAppList.add(app);
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    // ==================== Icon Loading ====================

    // Decode icon bytes into a down-sampled RGB_565 bitmap sized for the grid.
    private static Bitmap decodeIconBitmap(byte[] data) {
        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, opts);
            int sampleSize = 1;
            int w = opts.outWidth;
            int h = opts.outHeight;
            int targetSize = 120;
            while (w / sampleSize > targetSize * 2 || h / sampleSize > targetSize * 2) {
                sampleSize *= 2;
            }
            opts.inJustDecodeBounds = false;
            opts.inSampleSize = sampleSize;
            opts.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeByteArray(data, 0, data.length, opts);
        } catch (Exception ex) {
            return null;
        }
    }

    // Build the CDN URL list for a given icon path.
    private static String[] buildIconUrls(String iconPath) {
        if (iconPath.startsWith("http")) {
            return new String[]{iconPath};
        }
        String[] urls = new String[ICON_CDNS.length];
        for (int i = 0; i < ICON_CDNS.length; i++) {
            urls[i] = ICON_CDNS[i] + iconPath;
        }
        return urls;
    }

    // 图标并行竞速所有 CDN 节点，返回第一个成功的 byte[]（保留原竞速方式，不改）
    private static byte[] fetchIconRace(String[] urls) {
        final AtomicReference<byte[]> result = new AtomicReference<byte[]>(null);
        final AtomicReference<Boolean> done = new AtomicReference<Boolean>(false);
        final CountDownLatch allDone = new CountDownLatch(urls.length);

        for (final String urlStr : urls) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (done.get()) return;
                        URL url = new URL(urlStr);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        if (conn instanceof javax.net.ssl.HttpsURLConnection) {
                            ((javax.net.ssl.HttpsURLConnection) conn).setSSLSocketFactory(getSslFactoryStatic());
                        }
                        conn.setConnectTimeout(2000);
                        conn.setReadTimeout(3000);
                        conn.setUseCaches(false);
                        conn.setInstanceFollowRedirects(true);
                        if (conn.getResponseCode() == 200) {
                            InputStream is = conn.getInputStream();
                            byte[] data = readAllBytesStatic(is);
                            is.close();
                            conn.disconnect();
                            if (data != null && data.length > 0 && done.compareAndSet(false, true)) {
                                result.set(data);
                            }
                        } else {
                            conn.disconnect();
                        }
                    } catch (Exception ex) {
                    } finally {
                        allDone.countDown();
                    }
                }
            }).start();
        }

        while (!done.get() && allDone.getCount() > 0) {
            try { allDone.await(50, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { break; }
        }

        return result.get();
    }

    // 图标获取：磁盘缓存优先 → 网络竞速回源 → 成功异步写盘。
    // 首次启动磁盘 miss 时仅多一次 exists 判断，不影响首次加载速度。
    private static byte[] fetchIconOnce(String key, String[] urls) {
        android.content.Context ctx = sAppContext;
        if (ctx != null) {
            File f = new File(new File(ctx.getFilesDir(), ICON_DISK_DIR), md5(key) + ".png");
            if (f.exists() && f.length() > 0) {
                try {
                    byte[] cached = readAllBytesStatic(new FileInputStream(f));
                    if (cached != null && cached.length > 0) return cached;
                } catch (Exception ignored) {}
            }
        }
        byte[] data = fetchIconRace(urls);
        if (data != null && data.length > 0 && ctx != null) {
            try {
                File dir = new File(ctx.getFilesDir(), ICON_DISK_DIR);
                if (!dir.exists()) dir.mkdirs();
                FileOutputStream fos = new FileOutputStream(new File(dir, md5(key) + ".png"));
                fos.write(data);
                fos.close();
            } catch (Exception ignored) {}
        }
        return data;
    }

    private static String md5(String s) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] d = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (Exception ex) {
            return String.valueOf(s.hashCode());
        }
    }

    private void loadIconAsync(final String iconPath, final ImageView imageView) {
        if (iconPath == null || iconPath.isEmpty()) {
            imageView.setImageResource(RES_GJ_BANNER);
            return;
        }
        String fullUrl = iconPath.startsWith("http") ? iconPath : ICON_CDNS[0] + iconPath;

        // Check static LruCache first - if preloaded, show immediately
        Bitmap cached = sIconCache.get(fullUrl);
        if (cached != null) {
            imageView.setImageBitmap(cached);
            return;
        }
        imageView.setImageResource(RES_GJ_BANNER);

        final String urlStr = fullUrl;
        final String[] iconUrls = buildIconUrls(iconPath);
        final Handler handler = new Handler(Looper.getMainLooper());
        sIconExecutor.execute(new Runnable() {
            @Override
            public void run() {
                // Check cache again (might have been preloaded while waiting in queue)
                Bitmap cached2 = sIconCache.get(urlStr);
                if (cached2 != null) {
                    final Bitmap bmp = cached2;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            imageView.setImageBitmap(bmp);
                        }
                    });
                    return;
                }
                
                byte[] data = fetchIconOnce(urlStr, iconUrls);
                if (data == null) return;
                final Bitmap bmp = decodeIconBitmap(data);
                if (bmp != null) {
                    sIconCache.put(urlStr, bmp);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            imageView.setImageBitmap(bmp);
                        }
                    });
                }
            }
        });
    }

    // ==================== Network: Fetch JSON ====================

    // Always fetch the JSON fresh from the cloud on every call. If a
    // background preload already cached the JSON in memory, render it
    // immediately and refresh in the background.
    private void fetchData() {
        final Context ctx = e;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final LicenseUtil.AppListResult result = LicenseUtil.fetchAppList(ctx);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if (result == null || !result.ok) {
                            if (result != null && result.expired) {
                                handleExpired();
                            } else if (loadingText != null) {
                                loadingText.setText("\u52a0\u8f7d\u5931\u8d25\uff0c\u8bf7\u786e\u4fdd\u5df2\u7ecf\u8054\u7f51\uff0c\u53ef\u5de6\u53f3\u5207\u6362\u91cd\u65b0\u52a0\u8f7d");
                            }
                            return;
                        }
                        handleAppListResult(result);
                    }
                });
            }
        }).start();
    }

    private void handleAppListResult(LicenseUtil.AppListResult result) {
        if (result == null || result.apps == null) {
            if (loadingText != null) {
                loadingText.setText("\u52a0\u8f7d\u5931\u8d25\uff0c\u8bf7\u786e\u4fdd\u5df2\u7ecf\u8054\u7f51\uff0c\u53ef\u5de6\u53f3\u5207\u6362\u91cd\u65b0\u52a0\u8f7d");
            }
            return;
        }
        try {
            catList.clear();
            allAppList.clear();

            LinkedHashMap<String, CatData> catMap = new LinkedHashMap<String, CatData>();
            for (LicenseUtil.AppInfo info : result.apps) {
                AppData ad = new AppData();
                ad.name = info.name;
                ad.version = info.version;
                ad.description = info.description;
                if (info.beizhu != null && !info.beizhu.isEmpty()) {
                    ad.description = (ad.description == null || ad.description.isEmpty())
                        ? info.beizhu : ad.description + "\n" + info.beizhu;
                }
                ad.size = "";
                ad.icon = info.icon;
                ad.url = info.url;
                ad.dkey = (ad.url != null && !ad.url.isEmpty()) ? ad.url : ad.name;
                if (ad.name == null || ad.name.length() == 0) continue;
                allAppList.add(ad);

                String type = (info.type == null || info.type.isEmpty()) ? "\u5e94\u7528" : info.type.replaceFirst("^[0-9]+", "");
                if (type.isEmpty()) type = "\u5e94\u7528";
                CatData cd = catMap.get(type);
                if (cd == null) {
                    cd = new CatData();
                    cd.name = type;
                    catMap.put(type, cd);
                }
                cd.apps.add(ad);
            }
            catList.addAll(catMap.values());

            if (loadingText != null) {
                loadingText.setVisibility(View.INVISIBLE);
            }

            // 选中第一个分类并居中显示
            selectCategory(0);

            preloadIconsStatic(result.apps);
        } catch (Exception ex) {
            if (loadingText != null) {
                loadingText.setText("\u89e3\u6790\u5931\u8d25: " + ex.getMessage());
            }
        }
    }

    // 激活码已失效：回到激活界面重新输入（不清除 config.json，预填已保存的激活码，与原版一致）。
    private void handleExpired() {
        if (e == null) return;
        final Context ctx = e;
        android.content.SharedPreferences prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_ACTIVATED, false).apply();
        // 不清除 config.json 中的 appsCookie 和 appsPassword，原版也只显示登录框不清除数据
        Toast.makeText(ctx, "\u6fc0\u6d3b\u7801\u5df2\u8fc7\u671f\uff0c\u8bf7\u91cd\u65b0\u6fc0\u6d3b", Toast.LENGTH_LONG).show();
        View rootView = a;
        if (rootView instanceof android.widget.FrameLayout) {
            final android.widget.FrameLayout frame = (android.widget.FrameLayout) rootView;
            final float d = ctx.getResources().getDisplayMetrics().density;
            frame.removeAllViews();
            showLicenseView(ctx, frame, d, prefs);
        }
    }

    // ==================== Download progress tracking ====================

    // 正在下载中的应用集合（静态，跨界面重建保留）
    private static java.util.Set<String> downloadingApps = new java.util.HashSet<String>();
    // 已暂停下载的应用集合（静态，跨界面重建保留）
    private static java.util.Set<String> pausedApps = new java.util.HashSet<String>();
    // 下载线程池（静态，用于暂停/继续管理）
    private static java.util.Map<String, Thread> downloadThreads = new java.util.HashMap<String, Thread>();

    private int getDownloadProgress(String appName) {
        for (int i = 0; i < downloadProgressKeys.size(); i++) {
            if (downloadProgressKeys.get(i).equals(appName)) {
                return downloadProgressValues.get(i);
            }
        }
        return -1;
    }

    private void setDownloadProgress(String appName, int progress) {
        boolean found = false;
        for (int i = 0; i < downloadProgressKeys.size(); i++) {
            if (downloadProgressKeys.get(i).equals(appName)) {
                downloadProgressValues.set(i, progress);
                found = true;
                break;
            }
        }
        if (!found) {
            downloadProgressKeys.add(appName);
            downloadProgressValues.add(progress);
        }
    }

    private void removeDownloadProgress(String appName) {
        for (int i = downloadProgressKeys.size() - 1; i >= 0; i--) {
            if (downloadProgressKeys.get(i).equals(appName)) {
                downloadProgressKeys.remove(i);
                downloadProgressValues.remove(i);
            }
        }
    }

    private boolean isDownloading(String appName) {
        synchronized (downloadingApps) {
            return downloadingApps.contains(appName);
        }
    }

    private void markDownloading(String appName) {
        synchronized (downloadingApps) {
            downloadingApps.add(appName);
        }
    }

    private void unmarkDownloading(String appName) {
        synchronized (downloadingApps) {
            downloadingApps.remove(appName);
        }
    }

    private static boolean isPaused(String appName) {
        synchronized (pausedApps) {
            return pausedApps.contains(appName);
        }
    }

    private static void setPaused(String appName) {
        synchronized (pausedApps) {
            pausedApps.add(appName);
        }
    }

    private static void clearPaused(String appName) {
        synchronized (pausedApps) {
            pausedApps.remove(appName);
        }
    }

    // ==================== Download & Install ====================

    // ==================== Download helpers ====================

    // 应用下载 URL 由 app.php 返回（app.ahcjzs.cn），直接作为唯一候选地址。
    private static String[] buildDownloadUrls(String url) {
        return new String[]{url};
    }

    // Download an APK from a single URL, resume from offset if >0. Returns file on success, null on pause/failure.
    private static File downloadSingleApk(String url, File destFile, long offset, String appName,
                                          final Object progressLock, final MyProgressViewTest progressView,
                                          final TextView progressText, final TextView btn,
                                          final ProgressBar btnProgress, final DownloadProgressCallback cb) {
        java.util.ArrayList<String> referers = new java.util.ArrayList<String>();
        String ownReferer = null;
        try {
            java.net.URI uri = new java.net.URI(url);
            ownReferer = uri.getScheme() + "://" + uri.getHost() + "/";
        } catch (Exception ignored) {}
        if (ownReferer != null) referers.add(ownReferer);
        referers.add("https://app.ahcjzs.cn/");
        referers.add("");

        for (String referer : referers) {
            HttpURLConnection conn = null;
            java.io.RandomAccessFile raf = null;
            try {
                URL dlUrl = new URL(url);
                conn = (HttpURLConnection) dlUrl.openConnection();
                if (conn instanceof javax.net.ssl.HttpsURLConnection) {
                    ((javax.net.ssl.HttpsURLConnection) conn).setSSLSocketFactory(getSslFactoryStatic());
                }
                conn.setRequestMethod("GET");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0");
                if (referer != null && !referer.isEmpty()) {
                    conn.setRequestProperty("Referer", referer);
                }
                if (offset > 0) {
                    conn.setRequestProperty("Range", "bytes=" + offset + "-");
                }
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(60000);
                conn.setInstanceFollowRedirects(true);

                int code = conn.getResponseCode();
                if (code != 200 && code != 206) {
                    conn.disconnect();
                    continue;
                }

                long totalSize = 0;
                if (code == 206) {
                    long contentLen = conn.getContentLength();
                    totalSize = offset + (contentLen > 0 ? contentLen : 0);
                } else {
                    // 200: server doesn't support Range, start from scratch
                    offset = 0;
                    if (destFile.exists()) destFile.delete();
                    totalSize = conn.getContentLength();
                }

                InputStream is = conn.getInputStream();
                raf = new java.io.RandomAccessFile(destFile, "rw");
                if (offset > 0) raf.seek(offset);

                byte[] buf = new byte[8192];
                int len;
                long downloaded = offset;
                int lastProgress = -1;
                final Handler handler = new Handler(Looper.getMainLooper());
                while ((len = is.read(buf)) != -1) {
                    if (appName != null && isPaused(appName)) {
                        break;
                    }
                    raf.write(buf, 0, len);
                    downloaded += len;
                    if (totalSize > 0) {
                        final int pct = (int) ((downloaded * 100L) / totalSize);
                        if (pct != lastProgress) {
                            lastProgress = pct;
                            if (progressLock != null) {
                                synchronized (progressLock) {
                                    updateProgressUI(handler, progressView, progressText, btn, btnProgress, appName, pct);
                                }
                            } else {
                                updateProgressUI(handler, progressView, progressText, btn, btnProgress, appName, pct);
                            }
                            if (cb != null) cb.onProgress(pct);
                        }
                    }
                }
                raf.close();
                is.close();
                conn.disconnect();

                if (appName != null && isPaused(appName)) {
                    return null;
                }
                if (destFile.exists() && destFile.length() > 0) {
                    return destFile;
                }
            } catch (Exception ex) {
                if (conn != null) conn.disconnect();
                if (raf != null) { try { raf.close(); } catch (Exception ignored) {} }
            }
        }
        if (destFile.exists() && (appName == null || !isPaused(appName))) {
            destFile.delete();
        }
        return null;
    }

    private static void updateProgressUI(final Handler handler, final MyProgressViewTest progressView,
                                         final TextView progressText, final TextView btn,
                                         final ProgressBar btnProgress, final String appName,
                                         final int pct) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (progressView != null) progressView.setCurrentCount(pct);
                if (progressText != null) progressText.setText(pct + "%");
                if (btn != null) btn.setText(pct + "%");
                if (btnProgress != null) btnProgress.setProgress(pct);
            }
        });
    }

    // Callback interface for download progress updates
    private interface DownloadProgressCallback {
        void onProgress(int pct);
    }

    // Try multiple URLs with retry. Supports resume from offset. Returns null on success, "PAUSED" on pause, or error.
    private static String downloadWithRetry(String[] urls, File destFile, long offset, String appName,
                                            int maxRetriesPerUrl, DownloadProgressCallback cb) {
        java.util.HashSet<String> tried = new java.util.HashSet<String>();
        for (String url : urls) {
            if (tried.contains(url)) continue;
            tried.add(url);
            for (int attempt = 1; attempt <= maxRetriesPerUrl; attempt++) {
                if (appName != null && isPaused(appName)) {
                    return "PAUSED";
                }
                if (attempt > 1 && destFile.exists()) {
                    destFile.delete();
                    offset = 0;
                }
                File result = downloadSingleApk(url, destFile, offset, appName, null, null, null, null, null, cb);
                if (appName != null && isPaused(appName)) {
                    return "PAUSED";
                }
                if (result != null && result.exists() && result.length() > 0) {
                    return null;
                }
                if (attempt < maxRetriesPerUrl) {
                    try { Thread.sleep(1000L * attempt); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); return "PAUSED"; }
                }
            }
        }
        return "\u6240\u6709\u4e0b\u8f7d\u94fe\u63a5\u5747\u5931\u8d25\uff0c\u8bf7\u7a0d\u540e\u91cd\u8bd5";
    }

    // 刷新当前显示的应用列表，使下载/暂停/完成状态与 static 状态同步。
    // 下载线程的异步回调不能直接依赖旧 View：切换页面后 AppStorePage.k() 会重建
    // AppStoreFragment 与整棵 View，旧按钮已被移除，直接 setText 不再对用户可见。
    private static void refreshDownloadUi() {
        AppStoreFragment f = sActiveInstance.get();
        if (f != null && f.adapter != null) {
            f.adapter.notifyDataSetChanged();
        }
    }

    private void downloadAndInstall(final AppData app, final TextView btn, final ProgressBar btnProgress) {
        if (app.url == null || app.url.isEmpty()) {
            Toast.makeText(e, "\u8be5\u5e94\u7528\u6682\u65e0\u4e0b\u8f7d\u5730\u5740", Toast.LENGTH_SHORT).show();
            return;
        }

        final File finalFile = apkFileFor(app);
        final File tmpFile = new File(finalFile.getParentFile(), finalFile.getName() + ".part");

        // 已下载完成 → 直接安装
        if (finalFile.exists() && finalFile.length() > 0) {
            btn.setText("\u5b89\u88c5");
            btn.setTextColor(0xFFFFFFFF);
            btnProgress.setVisibility(View.GONE);
            installApk(finalFile);
            return;
        }

        // 正在下载中 → 暂停
        if (isDownloading(app.dkey)) {
            setPaused(app.dkey);
            btn.setText("\u7ee7\u7eed");
            btn.setTextColor(0xFFFFFFFF);
            return;
        }

        // 已暂停 → 继续下载
        if (isPaused(app.dkey)) {
            clearPaused(app.dkey);
            startDownloadContinue(app, btn, btnProgress, tmpFile, finalFile);
            return;
        }

        // 全新下载
        startDownloadNew(app, btn, btnProgress, tmpFile, finalFile);
    }

    // 开始全新下载
    private void startDownloadNew(final AppData app, final TextView btn, final ProgressBar btnProgress,
                                  final File tmpFile, final File finalFile) {
        if (tmpFile.exists()) tmpFile.delete();
        markDownloading(app.dkey);
        setDownloadProgress(app.dkey, 0);
        btn.setText("\u6682\u505c");
        btn.setTextColor(0xFFFFFFFF);
        btnProgress.setVisibility(View.VISIBLE);
        btnProgress.setProgress(0);

        final String[] candidateUrls = buildDownloadUrls(app.url);
        final long offset = 0;

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                final Handler handler = new Handler(Looper.getMainLooper());
                final String lastError = downloadWithRetry(candidateUrls, tmpFile, offset, app.dkey, 3, new DownloadProgressCallback() {
                    @Override
                    public void onProgress(final int pct) {
                        setDownloadProgress(app.dkey, pct);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                btn.setText("\u6682\u505c");
                                btn.setTextColor(0xFFFFFFFF);
                                btnProgress.setProgress(pct);
                                refreshDownloadUi();
                            }
                        });
                    }
                });

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isPaused(app.dkey)) {
                            unmarkDownloading(app.dkey);
                            clearPaused(app.dkey);
                            setPaused(app.dkey);
                            btn.setText("\u7ee7\u7eed");
                            btn.setTextColor(0xFFFFFFFF);
                            btnProgress.setVisibility(View.GONE);
                            refreshDownloadUi();
                            return;
                        }
                        unmarkDownloading(app.dkey);
                        if (lastError != null) {
                            removeDownloadProgress(app.dkey);
                            if (tmpFile.exists()) tmpFile.delete();
                            btn.setText("\u4e0b\u8f7d");
                            btn.setTextColor(0xFFFFFFFF);
                            btnProgress.setVisibility(View.GONE);
                            refreshDownloadUi();
                            Toast.makeText(e, "\u4e0b\u8f7d\u5931\u8d25: " + lastError, Toast.LENGTH_LONG).show();
                            return;
                        }
                        // 下载完成，重命名临时文件
                        tmpFile.renameTo(finalFile);
                        removeDownloadProgress(app.dkey);
                        btn.setText("\u5b89\u88c5");
                        btn.setTextColor(0xFFFFFFFF);
                        btnProgress.setVisibility(View.GONE);
                        refreshDownloadUi();
                        installApk(finalFile);
                    }
                });
            }
        });
        downloadThreads.put(app.dkey, t);
        t.start();
    }

    // 从断点继续下载
    private void startDownloadContinue(final AppData app, final TextView btn, final ProgressBar btnProgress,
                                       final File tmpFile, final File finalFile) {
        markDownloading(app.dkey);
        int prevPct = getDownloadProgress(app.dkey);
        btn.setText("\u6682\u505c");
        btn.setTextColor(0xFFFFFFFF);
        btnProgress.setVisibility(View.VISIBLE);
        if (prevPct >= 0) btnProgress.setProgress(prevPct);

        final String[] candidateUrls = buildDownloadUrls(app.url);
        final long offset = tmpFile.exists() ? tmpFile.length() : 0;

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                final Handler handler = new Handler(Looper.getMainLooper());
                final String lastError = downloadWithRetry(candidateUrls, tmpFile, offset, app.dkey, 3, new DownloadProgressCallback() {
                    @Override
                    public void onProgress(final int pct) {
                        setDownloadProgress(app.dkey, pct);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                btn.setText("\u6682\u505c");
                                btn.setTextColor(0xFFFFFFFF);
                                btnProgress.setProgress(pct);
                                refreshDownloadUi();
                            }
                        });
                    }
                });

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isPaused(app.dkey)) {
                            unmarkDownloading(app.dkey);
                            clearPaused(app.dkey);
                            setPaused(app.dkey);
                            btn.setText("\u7ee7\u7eed");
                            btn.setTextColor(0xFFFFFFFF);
                            btnProgress.setVisibility(View.GONE);
                            refreshDownloadUi();
                            return;
                        }
                        unmarkDownloading(app.dkey);
                        if (lastError != null) {
                            removeDownloadProgress(app.dkey);
                            clearPaused(app.dkey);
                            if (tmpFile.exists()) tmpFile.delete();
                            btn.setText("\u4e0b\u8f7d");
                            btn.setTextColor(0xFFFFFFFF);
                            btnProgress.setVisibility(View.GONE);
                            refreshDownloadUi();
                            Toast.makeText(e, "\u4e0b\u8f7d\u5931\u8d25: " + lastError, Toast.LENGTH_LONG).show();
                            return;
                        }
                        tmpFile.renameTo(finalFile);
                        removeDownloadProgress(app.dkey);
                        clearPaused(app.dkey);
                        btn.setText("\u5b89\u88c5");
                        btn.setTextColor(0xFFFFFFFF);
                        btnProgress.setVisibility(View.GONE);
                        refreshDownloadUi();
                        installApk(finalFile);
                    }
                });
            }
        });
        downloadThreads.put(app.dkey, t);
        t.start();
    }

    /**
     * 安装 APK：完全复用原版（应用管家）的统一安装逻辑，并跟随管家里的"安装器"设置。
     * 读取 com.ahcjzs.util.v.a.b0（0=管家安装器 / 1=系统安装器 / 2=指定安装器 / 3=由打开方式）：
     *  - 类型 0：管家静默安装 ia.d.a.d(path)，与管家"文件管理/应用安装"的分流完全一致。
     *  - 其它：走原版统一入口 w8.n.W，由其按类型分发到系统 / 指定 / 打开方式安装器。
     */
    private void installApk(final File apkFile) {
        if (apkFile == null || !apkFile.exists()) {
            return;
        }
        final String path = apkFile.getAbsolutePath();
        if (com.ahcjzs.util.v.a.b0 == 0) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String err = ia.d.a.d(path);
                    final String msg = (err == null || err.isEmpty()) ? "安装成功" : ("安装失败：" + err);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(e, msg, msg.startsWith("安装成功") ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }).start();
        } else {
            w8.n.W(e, path);
        }
    }

    private String formatSize(int bytes) {
        if (bytes < 1024) return bytes + "B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + "KB";
        return (bytes / (1024 * 1024)) + "MB";
    }

    // 计算该应用的本地 APK 文件路径
    private File apkFileFor(AppData app) {
        String safeName = (app.name != null ? app.name : "app").replaceAll("[^a-zA-Z0-9._\u4e00-\u9fff]", "_");
        String uid = Integer.toHexString((app.dkey != null ? app.dkey : app.name).hashCode());
        return new File(e.getExternalCacheDir(), safeName + "_" + uid + ".apk");
    }

    // 该应用是否已下载（本地文件存在且非空）
    private boolean isApkDownloaded(AppData app) {
        if (app == null || e == null) return false;
        File f = apkFileFor(app);
        return f.exists() && f.length() > 0;
    }

    // 应用详情弹窗：显示图标、名称、版本、大小、更新说明、下载/安装按钮（比例参考激活框）
    private void showAppDetailDialog(final AppData app) {
        if (e == null || app == null) return;
        final Context ctx = e;
        final float d = ctx.getResources().getDisplayMetrics().density;

        final android.app.Dialog dialog = new android.app.Dialog(ctx);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);

        // 根布局：垂直排列，蓝色圆角详情框
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable rootBg = new GradientDrawable();
        rootBg.setCornerRadius((int)(20 * d));
        rootBg.setColor(0xFF1B4A8A);
        root.setBackground(rootBg);
        root.setPadding((int)(22 * d), (int)(20 * d), (int)(22 * d), (int)(20 * d));

        // === 第1行：图标 + 软件名 ===
        LinearLayout topRow = new LinearLayout(ctx);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);

        final ImageView icon = new ImageView(ctx);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int iconSize = (int)(96 * d);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setCornerRadius((int)(14 * d));
        iconBg.setColor(0xFFFFFFFF);
        iconBg.setStroke((int)(1 * d), 0x33FFFFFF);
        icon.setBackground(iconBg);
        icon.setPadding((int)(6 * d), (int)(6 * d), (int)(6 * d), (int)(6 * d));
        topRow.addView(icon, new LinearLayout.LayoutParams(iconSize, iconSize));
        loadIconAsync(app.icon, icon);

        TextView name = new TextView(ctx);
        name.setText(app.name != null ? app.name : "");
        name.setTextColor(0xFFFFFFFF);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        nameLp.leftMargin = (int)(16 * d);
        topRow.addView(name, nameLp);

        root.addView(topRow, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // === 第2行：版本号 + 大小 ===
        String verLine = "";
        if (app.version != null && app.version.length() > 0) verLine = "\u7248\u672c\uff1a" + app.version;
        if (app.size != null && app.size.length() > 0) {
            if (verLine.length() > 0) verLine += "    ";
            verLine += "\u5927\u5c0f\uff1a" + app.size;
        }
        TextView verTv = new TextView(ctx);
        verTv.setText(verLine.length() > 0 ? verLine : "\u7248\u672c\u4fe1\u606f\u65e0");
        verTv.setTextColor(0xFFB7D4F5);
        verTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        verTv.setGravity(Gravity.LEFT);
        verTv.setPadding((int)(2 * d), (int)(14 * d), 0, 0);
        root.addView(verTv, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // === 第3行：更新说明 ===
        TextView descTitle = new TextView(ctx);
        descTitle.setText("\u66f4\u65b0\u8bf4\u660e");
        descTitle.setTextColor(0xFF8FC7FF);
        descTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        descTitle.setTypeface(Typeface.DEFAULT_BOLD);
        descTitle.setPadding((int)(2 * d), (int)(14 * d), 0, 0);
        root.addView(descTitle, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        String desc = (app.description != null && app.description.length() > 0)
            ? app.description : "\u6682\u65e0\u8bf4\u660e";
        TextView descTv = new TextView(ctx);
        descTv.setText(desc);
        descTv.setTextColor(0xFFD9E8FA);
        descTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        descTv.setGravity(Gravity.LEFT);
        descTv.setLineSpacing((int)(3 * d), 1f);
        descTv.setPadding((int)(2 * d), (int)(6 * d), (int)(2 * d), (int)(16 * d));
        root.addView(descTv, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // === 第4行：取消 + 下载/安装 按钮 ===
        LinearLayout btnRow = new LinearLayout(ctx);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER);

        final TextView cancelBtn = new TextView(ctx);
        cancelBtn.setText("\u53d6\u6d88");
        cancelBtn.setTextColor(0xFFFFFFFF);
        cancelBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        cancelBtn.setTypeface(Typeface.DEFAULT_BOLD);
        cancelBtn.setGravity(Gravity.CENTER);
        GradientDrawable cancelBg = new GradientDrawable();
        cancelBg.setCornerRadius((int)(10 * d));
        cancelBg.setColor(0xFF4A6FA5);
        cancelBtn.setBackground(cancelBg);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(
            0, (int)(52 * d), 1f);
        cancelLp.rightMargin = (int)(14 * d);
        btnRow.addView(cancelBtn, cancelLp);

        final TextView dlBtn = new TextView(ctx);
        final boolean hasUrl = (app.url != null && app.url.length() > 0);
        final boolean downloaded = isApkDownloaded(app);
        final boolean downloading = isDownloading(app.dkey);
        final boolean paused = isPaused(app.dkey);
        String btnText = "\u6682\u65e0";
        if (hasUrl) {
            if (downloaded) btnText = "\u5b89\u88c5";
            else if (downloading) btnText = "\u6682\u505c";
            else if (paused) btnText = "\u7ee7\u7eed";
            else btnText = "\u4e0b\u8f7d";
        }
        dlBtn.setText(btnText);
        dlBtn.setTextColor(0xFFFFFFFF);
        dlBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        dlBtn.setTypeface(Typeface.DEFAULT_BOLD);
        dlBtn.setGravity(Gravity.CENTER);
        GradientDrawable dlBg = new GradientDrawable();
        dlBg.setCornerRadius((int)(10 * d));
        dlBg.setColor(hasUrl ? 0xFF2E86DE : 0xFF555555);
        dlBtn.setBackground(dlBg);
        btnRow.addView(dlBtn, new LinearLayout.LayoutParams(0, (int)(52 * d), 1f));

        final ProgressBar dlProgress = new ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal);
        dlProgress.setMax(100);
        dlProgress.setProgress(0);
        dlProgress.setVisibility(View.GONE);
        dlProgress.setProgressDrawable(makeProgressDrawable(d));
        LinearLayout.LayoutParams dlProgLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, (int)(8 * d));
        dlProgLp.topMargin = (int)(10 * d);
        root.addView(dlProgress, dlProgLp);

        root.addView(btnRow, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (hasUrl) {
            dlBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    downloadAndInstall(app, dlBtn, dlProgress);
                }
            });
        }

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        // 对话框容器宽度与激活框一致（530dp）
        LinearLayout wrap = new LinearLayout(ctx);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.addView(root, new LinearLayout.LayoutParams(
            (int)(530 * d), ViewGroup.LayoutParams.WRAP_CONTENT));

        dialog.setContentView(wrap);
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.show();
    }

    // ==================== 参考图布局：应用网格 Adapter（横向卡片）====================

    private class AppGridAdapter extends BaseAdapter {
        private Context ctx;
        private float density;

        AppGridAdapter(Context ctx, float d) {
            this.ctx = ctx;
            this.density = d;
        }

        @Override
        public int getCount() { return filteredAppList.size(); }

        @Override
        public Object getItem(int position) { return filteredAppList.get(position); }

        @Override
        public long getItemId(int position) { return (long) position; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final AppData item = (AppData) filteredAppList.get(position);

            // === 卡片：横向布局 icon | text | button，固定高度保证对称 ===
            LinearLayout card = new LinearLayout(ctx);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            int pad = (int)(6 * density);
            card.setPadding(pad, (int)(5 * density), pad, (int)(5 * density));
            card.setFocusable(true);
            card.setClickable(true);
            // 固定卡片高度，保证所有卡片大小对称一致
            int cardHeight = (int)(64 * density);
            card.setMinimumHeight(cardHeight);

            // 卡片背景：半透明深蓝圆角
            StateListDrawable cardBg = new StateListDrawable();
            GradientDrawable focusedCard = new GradientDrawable();
            focusedCard.setCornerRadius((int)(8 * density));
            focusedCard.setColor(0xDD2D4A6F);
            focusedCard.setStroke((int)(2 * density), COLOR_PURPLE);
            cardBg.addState(new int[]{android.R.attr.state_focused}, focusedCard);
            cardBg.addState(new int[]{android.R.attr.state_pressed}, focusedCard);
            GradientDrawable normalCard = new GradientDrawable();
            normalCard.setCornerRadius((int)(8 * density));
            normalCard.setColor(COLOR_CARD_BG);
            cardBg.addState(new int[]{}, normalCard);
            card.setBackground(cardBg);

            // === Icon (left) ===
            ImageView icon = new ImageView(ctx);
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            icon.setAdjustViewBounds(true);
            int iconSize = (int)(36 * density);
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(iconSize, iconSize);
            iconParams.setMarginEnd((int)(6 * density));
            card.addView(icon, iconParams);
            loadIconAsync(item.icon, icon);
            // 点击图标弹出应用详情框
            icon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showAppDetailDialog(item);
                }
            });

            // === Text block (middle) ===
            LinearLayout textBlock = new LinearLayout(ctx);
            textBlock.setOrientation(LinearLayout.VERTICAL);
            textBlock.setGravity(Gravity.CENTER_VERTICAL);

            TextView name = new TextView(ctx);
            name.setText(item.name);
            // 云端控制颜色：nameColor非0则使用服务端下发颜色，否则默认白色
            name.setTextColor(item.nameColor != 0 ? item.nameColor : 0xFFFFFFFF);
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            textBlock.addView(name, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            // Version line
            String verLine = "";
            if (item.version != null && item.version.length() > 0) {
                verLine = item.version;
            }
            if (item.size != null && item.size.length() > 0) {
                if (verLine.length() > 0) verLine += "  ";
                verLine += item.size;
            }
            if (verLine.length() == 0) verLine = "\u7248\u672c\u53f7";
            TextView version = new TextView(ctx);
            version.setText(verLine);
            version.setTextColor(0xFF9CA3AF);
            version.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            version.setSingleLine(true);
            textBlock.addView(version);

            // Description line
            String descText = (item.description != null && item.description.length() > 0)
                ? item.description : "\u5907\u6ce8";
            TextView desc = new TextView(ctx);
            desc.setText(descText);
            // 云端控制颜色：descColor非0则使用服务端下发颜色，否则默认橙色
            desc.setTextColor(item.descColor != 0 ? item.descColor : 0xFFF97316);
            desc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
            desc.setLines(3);
            desc.setEllipsize(TextUtils.TruncateAt.END);
            desc.setGravity(Gravity.TOP);
            textBlock.addView(desc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            card.addView(textBlock, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            // === Download button (right) ===
            LinearLayout btnContainer = new LinearLayout(ctx);
            btnContainer.setOrientation(LinearLayout.VERTICAL);
            btnContainer.setGravity(Gravity.CENTER);

            final TextView dlBtn = new TextView(ctx);
            final boolean hasUrl = (item.url != null && item.url.length() > 0);
            final boolean apkDownloaded = isApkDownloaded(item);
            final boolean downloading = isDownloading(item.dkey);
            final boolean paused = isPaused(item.dkey);
            String btnText = "\u6682\u65e0";
            if (hasUrl) {
                if (apkDownloaded) btnText = "\u5b89\u88c5";
                else if (downloading) btnText = "\u6682\u505c";
                else if (paused) btnText = "\u7ee7\u7eed";
                else btnText = "\u4e0b\u8f7d";
            }
            dlBtn.setText(btnText);
            dlBtn.setTextColor(0xFFFFFFFF);
            dlBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            dlBtn.setGravity(Gravity.CENTER);
            // 不抢焦点：下载由卡片整体点击触发（焦点在卡片上按OK即下载，与原版TvRecyclerView一致）
            dlBtn.setFocusable(false);
            dlBtn.setClickable(true);
            dlBtn.setMinWidth((int)(50 * density));
            dlBtn.setPadding((int)(8 * density), (int)(5 * density), (int)(8 * density), (int)(5 * density));
            // 允许文字换行，避免按钮文字被截断
            dlBtn.setSingleLine(false);
            dlBtn.setMaxLines(2);

            StateListDrawable btnBgDrawable = new StateListDrawable();
            GradientDrawable focusedBtn = new GradientDrawable();
            focusedBtn.setCornerRadius((int)(5 * density));
            focusedBtn.setColor(0xFF0051A8);
            focusedBtn.setStroke((int)(2 * density), COLOR_PURPLE);
            btnBgDrawable.addState(new int[]{android.R.attr.state_focused}, focusedBtn);
            btnBgDrawable.addState(new int[]{android.R.attr.state_pressed}, focusedBtn);
            if (hasUrl) {
                GradientDrawable normalBtn = new GradientDrawable();
                normalBtn.setCornerRadius((int)(5 * density));
                normalBtn.setColor(COLOR_DOWNLOAD_BTN);
                btnBgDrawable.addState(new int[]{}, normalBtn);
            } else {
                GradientDrawable disabledBtn = new GradientDrawable();
                disabledBtn.setCornerRadius((int)(5 * density));
                disabledBtn.setColor(0xFF555555);
                btnBgDrawable.addState(new int[]{}, disabledBtn);
            }
            dlBtn.setBackground(btnBgDrawable);

            // Progress bar under button
            final ProgressBar btnProgress = new ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal);
            btnProgress.setMax(100);
            btnProgress.setProgress(0);
            btnProgress.setVisibility(View.GONE);
            LinearLayout.LayoutParams progParams = new LinearLayout.LayoutParams(
                (int)(50 * density), (int)(3 * density));
            progParams.setMargins(0, (int)(2 * density), 0, 0);
            btnProgress.setProgressDrawable(makeProgressDrawable(density));

            // Check if this app is currently downloading
            int existingProgress = getDownloadProgress(item.dkey);
            if (downloading && existingProgress >= 0) {
                dlBtn.setText(existingProgress + "%");
                btnProgress.setVisibility(View.VISIBLE);
                btnProgress.setProgress(existingProgress);
            }

            if (hasUrl) {
                dlBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        downloadAndInstall(item, dlBtn, btnProgress);
                    }
                });
            }

            btnContainer.addView(dlBtn);
            btnContainer.addView(btnProgress, progParams);

            card.addView(btnContainer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            // === 卡片整体作为焦点+点击单元：焦点在卡片上按OK即下载（与原版TvRecyclerView一致）===
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    downloadAndInstall(item, dlBtn, btnProgress);
                }
            });

            return card;
        }
    }

    private android.graphics.drawable.Drawable makeProgressDrawable(float d) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius((int)(2 * d));
        bg.setColor(0xFF334155);
        GradientDrawable fill = new GradientDrawable();
        fill.setCornerRadius((int)(2 * d));
        fill.setColor(COLOR_DOWNLOAD_BTN);
        android.graphics.drawable.ClipDrawable clip = new android.graphics.drawable.ClipDrawable(
            fill, Gravity.LEFT, android.graphics.drawable.ClipDrawable.HORIZONTAL);
        android.graphics.drawable.LayerDrawable layers = new android.graphics.drawable.LayerDrawable(
            new android.graphics.drawable.Drawable[]{bg, clip});
        layers.setId(0, android.R.id.background);
        layers.setId(1, android.R.id.progress);
        return layers;
    }
}
