package androidx.core.content;

import android.content.Context;
import android.net.Uri;
import java.io.File;

public class FileProvider {
    // ProGuard 混淆后方法名为 c(Context, String, File)
    public static Uri c(Context context, String authority, File file) {
        return Uri.fromFile(file);
    }
}
