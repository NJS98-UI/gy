package z9;

public class p extends g {
    // 占位 Fragment：应用管理 tab 对应的 ViewPager 页。
    // 导航聚焦/点击到该 tab 时会直接跳转 ActivityApps，本页不会真正展示，
    // 仅用于保证标题列表与 Fragment 列表数量一致，避免 getItem 越界。
    // 复用原「功能面板」布局 fragment_cmd (0x7f0e0112)，保证 inflate 不崩溃。
    public int j() { return 0x7f0e0112; }
    public void k() {}
}