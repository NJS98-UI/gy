package z9;

import android.content.Context;
import android.view.View;
import android.app.Activity;

public abstract class g {
    public View a;
    public boolean b;
    public boolean c;
    public boolean d;
    public Context e;
    public Activity f;

    public int j() { return 0; }
    public void k() {}
}
