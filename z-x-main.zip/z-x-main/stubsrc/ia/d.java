package ia;

/**
 * 编译期存根（stub）——原版混淆类 ia.d 的占位。
 *
 * 仅用于 build.sh 的 javac 阶段通过编译，运行时调用的是原版真实的 ia.d
 * （位于 gongqian_apk 内，以 smali 形式存在）。本存根不会被注入到 APK。
 *
 * 真实字节码：
 *   .field public static final a:Lia/e;
 */
public abstract class d {
    public static e a;
}