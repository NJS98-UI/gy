package ia;

/**
 * 编译期存根（stub）——原版混淆类 ia.e 的占位。
 *
 * 仅用于 build.sh 的 javac 阶段通过编译，运行时调用的是原版真实的 ia.e
 * （位于 gongqian_apk 内，以 smali 形式存在）。本存根不会被注入到 APK。
 *
 * d(String) 即"管家安装器"的同步静默安装：返回空串=成功，否则为错误信息。
 *
 * 真实字节码：
 *   .method public final d(Ljava/lang/String;)Ljava/lang/String;
 */
public class e {
    public String d(String apkPath) {
        return null; // 占位返回，仅用于通过编译，运行时不会执行。
    }
}