package w8;

import android.content.Context;

/**
 * 编译期存根（stub）——原版混淆类 w8.n 的占位。
 *
 * 用途：AppStoreFragment 的下载完成安装逻辑完全复用原版统一安装入口
 *        w8.n.W(Context, apkPath)，但在 build.sh 的 javac 阶段，
 *        原版的 w8.n 仍以 smali 形式存在（位于 gongqian_apk 内），
 *        编译器无法解析，故提供本存根让 javac 通过。
 *
 * 注意：build.sh 第 4 步仅注入 com/appstore、z9、com/ahcjzs/view 三个目录，
 *       本存根不会被注入到 APK；运行时调用的是原版真实的 w8.n.W，
 *       因此安装行为与原版完全一致（含 FileProvider、未知来源权限、
 *       安装器类型分流与管家静默安装）。
 */
public class n {
    public static void W(Context context, String apkPath) {
        // 占位实现：仅用于通过编译，运行时不会执行。
    }
}