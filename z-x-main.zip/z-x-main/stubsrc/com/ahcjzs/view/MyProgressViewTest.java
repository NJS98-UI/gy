package com.ahcjzs.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

// 编译期 stub：运行时使用 APK 内真实的 com.ahcjzs.view.MyProgressViewTest。
public class MyProgressViewTest extends View {
    public MyProgressViewTest(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setCurrentCount(float count) {
    }

    public void setMaxCount(float count) {
    }
}
