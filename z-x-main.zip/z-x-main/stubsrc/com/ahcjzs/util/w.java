package com.ahcjzs.util;

/**
 * 编译期存根（stub）——原版混淆类 com.ahcjzs.util.w 的占位。
 *
 * 仅用于 build.sh 的 javac 阶段通过编译，运行时调用的是原版真实的 w
 * （位于 gongqian_apk 内，以 smali 形式存在）。本存根不会被注入到 APK。
 *
 * b0 即"安装器设置"：
 *   0 = 管家安装器（静默安装）
 *   1 = 系统安装器
 *   2 = 指定安装器
 *   3 = 由打开方式
 *
 * 真实字节码：
 *   .field public b0:I
 */
public class w {
    public int b0;
}