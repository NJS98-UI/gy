#!/usr/bin/env python3
"""Fix version info display in function panel (pa/u7.smali)

Problem:
  The version info ("当前使用的版本：v1.9.1.1907 公签版") was missing from
  the bottom of the function panel. Root cause: a background thread sends
  message 0x7b which triggers q() to update the version TextView, but this
  happens before the Fragment's k() method has initialized the TextView (j).
  When q() runs with j==null, it either NPEs (caught by Handler try-catch)
  or silently fails, so the version info is never displayed.

Fix:
  1. In k() method: call q() at the end, after TextView j is initialized,
     so version info is populated when the Fragment view is created.
  2. In q() method: add null check for j to prevent NPE when called from
     the Handler before k() runs. If j is null, skip the update gracefully.
"""

import sys
import os


def fix_u7_smali(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    changed = False

    # ── Fix 1: Add q() call at end of k() method ──
    # k() ends with:
    #     invoke-virtual {v0, v1}, Lvb/b;->b(Lvb/e;)V
    #
    #     .line 108
    #     .line 109
    #     .line 110
    #     return-void
    # .end method
    #
    # Insert invoke-virtual {p0}, Lpa/u7;->q()V before return-void

    k_pattern = (
        "    invoke-virtual {v0, v1}, Lvb/b;->b(Lvb/e;)V\n"
        "\n"
        "    .line 108\n"
        "    .line 109\n"
        "    .line 110\n"
        "    return-void\n"
        ".end method\n"
    )

    k_replacement = (
        "    invoke-virtual {v0, v1}, Lvb/b;->b(Lvb/e;)V\n"
        "\n"
        "    .line 108\n"
        "    .line 109\n"
        "    .line 110\n"
        "    invoke-virtual {p0}, Lpa/u7;->q()V\n"
        "\n"
        "    return-void\n"
        ".end method\n"
    )

    if k_pattern in content:
        content = content.replace(k_pattern, k_replacement, 1)
        changed = True
        print("  [1/3] 已在 k() 方法末尾添加 q() 调用")
    else:
        print("  [1/3] 跳过: k() 方法结尾模式未找到 (可能已修复)")

    # ── Fix 2a: Add null check in q() after loading TextView j ──
    # q() starts with:
    #     iget-object v0, p0, Lpa/u7;->j:Landroid/widget/TextView;
    #
    #     .line 2
    #     .line 3
    #     invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;
    #
    # Insert if-eqz v0, :cond_u7_q_null after the iget-object

    q_start_pattern = (
        "    iget-object v0, p0, Lpa/u7;->j:Landroid/widget/TextView;\n"
        "\n"
        "    .line 2\n"
        "    .line 3\n"
        "    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;"
    )

    q_start_replacement = (
        "    iget-object v0, p0, Lpa/u7;->j:Landroid/widget/TextView;\n"
        "\n"
        "    if-eqz v0, :cond_u7_q_null\n"
        "\n"
        "    .line 2\n"
        "    .line 3\n"
        "    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;"
    )

    if q_start_pattern in content:
        content = content.replace(q_start_pattern, q_start_replacement, 1)
        changed = True
        print("  [2/3] 已在 q() 方法添加 TextView null 检查")
    else:
        print("  [2/3] 跳过: q() 方法开头模式未找到 (可能已修复)")

    # ── Fix 2b: Add :cond_u7_q_null label before final return-void of q() ──
    # q() ends with:
    #     invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    #
    #     .line 519
    #     .line 520
    #     .line 521
    #     return-void
    # .end method
    #
    # Insert :cond_u7_q_null label before return-void

    q_end_pattern = (
        "    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V\n"
        "\n"
        "    .line 519\n"
        "    .line 520\n"
        "    .line 521\n"
        "    return-void\n"
        ".end method\n"
    )

    q_end_replacement = (
        "    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V\n"
        "\n"
        "    .line 519\n"
        "    .line 520\n"
        "    .line 521\n"
        "    :cond_u7_q_null\n"
        "    return-void\n"
        ".end method\n"
    )

    if q_end_pattern in content:
        content = content.replace(q_end_pattern, q_end_replacement, 1)
        changed = True
        print("  [3/3] 已在 q() 方法末尾添加 null 检查跳转标签")
    else:
        print("  [3/3] 跳过: q() 方法结尾模式未找到 (可能已修复)")

    if changed:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print("  pa/u7.smali 版本信息显示修复完成")
    else:
        print("  pa/u7.smali 无需修改 (已修复或模式不匹配)")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 fix_version_display.py <gongqian_apk_dir>")
        sys.exit(1)

    gongqian_dir = sys.argv[1]
    u7_path = os.path.join(gongqian_dir, "smali", "pa", "u7.smali")

    if os.path.exists(u7_path):
        print(f"修复版本信息显示: {u7_path}")
        fix_u7_smali(u7_path)
    else:
        print(f"!! 错误: {u7_path} 不存在")
        sys.exit(1)
