#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
资源 ID 重映射脚本（含缺失布局注入）
====================================
AppStoreFragment.smali 由 YYGJ 编译产生, 其内硬编码了 YYGJ APK 编译时的资源 ID。
注入到新版应用管家 APK 后, 这些 ID 与目标 APK 的 public.xml 不匹配, 导致:
  1. 更新对话框 inflate 失败 (0x7f0e00fe 是 YYGJ 的 dialog_updata 布局 ID)
  2. 对话框内控件 findViewById 全部返回 null
  3. 应用商店主布局 fragment_appstore (LAYOUT_ID=0x7f0e0218) 在新版 APK 中
     缺失, onCreateView inflate 时抛 Resources.NotFoundException 直接闪退

本脚本扫描目标 APK 的 res/values/public.xml, 按资源名字面解析出真实 ID,
再用这些值替换 smali 中的硬编码 ID。对于缺失的 fragment_appstore 布局,
会自动在 public.xml 中注入一条 public 条目并分配空闲 ID, 从而在不动
AppStoreFragment.java 的情况下修复闪退。

用法:
    python3 remap_resids.py <public.xml> <AppStoreFragment.smali>
"""
import sys
import re


def load_public_ids(public_xml):
    """解析 public.xml, 返回 {type|name: id} 与 {name: id} 两个映射。"""
    by_type_name = {}
    by_name = {}
    pattern = re.compile(
        r'<public\s+type="([^"]+)"\s+name="([^"]+)"\s+id="(0x[0-9a-fA-F]+)"'
    )
    with open(public_xml, "r", encoding="utf-8") as f:
        for line in f:
            m = pattern.search(line)
            if m:
                rtype, name, rid = m.group(1), m.group(2), m.group(3)
                key = "%s|%s" % (rtype, name)
                by_type_name[key] = rid
                by_name.setdefault(name, rid)
    return by_type_name, by_name


def find_free_id(by_type_name, rtype, preferred):
    """在指定资源类型下找一个空闲 ID, 优先使用 preferred。"""
    used = set()
    prefix = rtype + "|"
    for key, rid in by_type_name.items():
        if key.startswith(prefix):
            used.add(int(rid, 16))
    pref = int(preferred, 16)
    if pref not in used:
        return "0x%08x" % pref
    low = (pref >> 16) << 16
    high = low + 0xFFFF
    for rid in range(low, high + 1):
        if rid not in used:
            return "0x%08x" % rid
    return None


def ensure_layout(public_xml, by_type_name, name, preferred):
    """确保名为 name 的 layout 资源存在于 public.xml, 返回其 ID。
    若不存在则在 public.xml 末尾追加 public 条目并返回分配的空闲 ID。"""
    key = "layout|" + name
    if key in by_type_name:
        return by_type_name[key]
    free_id = find_free_id(by_type_name, "layout", preferred)
    if free_id is None:
        return None
    with open(public_xml, "r", encoding="utf-8") as f:
        content = f.read()
    entry = '    <public type="layout" name="%s" id="%s" />\n' % (name, free_id)
    if "</resources>" in content:
        content = content.replace("</resources>", entry + "</resources>")
    else:
        content += entry
    with open(public_xml, "w", encoding="utf-8") as f:
        f.write(content)
    by_type_name[key] = free_id
    print("  注入缺失布局: %s -> %s" % (name, free_id))
    return free_id


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)

    public_xml, smali_file = sys.argv[1], sys.argv[2]
    by_type_name, by_name = load_public_ids(public_xml)

    # 确保 AppStoreFragment 主布局 fragment_appstore 存在
    # (新版应用管家 APK 缺失该布局, 直接 inflate 会闪退)
    ensure_layout(public_xml, by_type_name, "fragment_appstore", "0x7f0e0218")

    # 需要重映射的映射表: smali 中的硬编码 ID -> (资源类型, 资源名)
    # 这些 ID 来自 YYGJ 编译产物, 通过目标 public.xml 按名解析真实值。
    mapping = {
        "0x7f0e0218": "layout|fragment_appstore",
        "0x7f0e00fe": "layout|dialog_updata",
        "0x7f0b0414": "id|v_dialog_btn_no",
        "0x7f0b0416": "id|v_dialog_btn_yes",
        "0x7f0b041a": "id|v_dialog_progress",
        "0x7f0b041b": "id|v_dialog_progress_text",
        "0x7f0b041c": "id|v_dialog_version",
        "0x7f0b05eb": "id|v_update_text",
    }

    resolved = {}
    missing = []
    for hardcoded, key in mapping.items():
        rid = by_type_name.get(key)
        if rid is None:
            # 该类型|名字未找到, 退一步按名字找 (容忍类型前缀不同)
            rtype, name = key.split("|", 1)
            rid = by_name.get(name)
        if rid is None:
            missing.append(key)
        else:
            resolved[hardcoded] = (key, rid)

    if missing:
        print("!! 警告: 以下资源在 public.xml 中未找到, 跳过:")
        for k in missing:
            print("    - %s" % k)

    if not resolved:
        print("!! 错误: 没有可用的资源映射, 退出")
        sys.exit(2)

    with open(smali_file, "r", encoding="utf-8") as f:
        c = f.read()

    replaced = 0
    for hardcoded, (key, rid) in resolved.items():
        rtype, name = key.split("|", 1)
        # smart 匹配: 小写十六进制, 统一替换
        if hardcoded in c:
            c = c.replace(hardcoded, rid)
            replaced += 1
            print("  重映射: %s (%s>%s) -> %s" % (hardcoded, rtype, name, rid))
        else:
            print("  跳过: %s (%s>%s) 在 smali 中未出现" % (hardcoded, rtype, name))

    with open(smali_file, "w", encoding="utf-8") as f:
        f.write(c)

    print("资源重映射完成: %d/%d 替换成功" % (replaced, len(resolved)))
    if missing:
        sys.exit(3)


if __name__ == "__main__":
    main()
