#!/usr/bin/env python3
"""解锁安装器设置（a5/f.smali 的 b(I) 方法）。

背景：
  原版应用管家在"系统 UID（公签版，Process.myUid()==1000）"运行时，
  会在安装器设置点击回调 b(I) 里强制把 b0（安装器设置）重置为 0（管家安装器），
  并弹 toast"公签UID版版，只能使用管家安装器"。
  这导致公签版用户无法自由切换"系统安装器 / 指定安装器 / 由打开方式"，
  应用商店的下载安装自然也就"不跟随设置"。

修复：
  把该强制的条件跳转 if-eqz p1, :label 改为无条件的 goto :label，
  使这段"强制 A(0) + toast"的代码永远不执行，用户的安装器选择得以正常保存。
  （AppStoreFragment.installApk 已经按 b0 分流：0=管家静默，其余走 w8.n.W 分发。）
"""

import os
import re
import sys


def unlock(fn):
    with open(fn, 'r', encoding='utf-8') as f:
        content = f.read()

    # 匹配"公签版强制管家安装器"的进入条件：
    #   iget-boolean p1, p1, Lcom/ahcjzs/util/k;->i:Z
    #   （空行）
    #   .line N
    #   .line N
    #   if-eqz p1, :label
    # 该 iget-boolean（k.i）在本方法里出现两处，另一处后面跟的是 if-nez，
    # 因此用 if-eqz 收尾可以唯一定位到强制块。
    pattern = re.compile(
        r'(iget-boolean p1, p1, Lcom/ahcjzs/util/k;->i:Z\n'
        r'\n'
        r'    \.line \d+\n'
        r'    \.line \d+\n'
        r'    )if-eqz p1, :(\w+)'
    )

    new_content, n = pattern.subn(r'\1goto :\2', content, count=1)

    if n == 0:
        with open(fn, 'w', encoding='utf-8') as f:
            f.write(content)
        print("  跳过: 未找到公签版强制安装器的条件跳转 (可能已解锁或新版结构变化)")
        return False

    with open(fn, 'w', encoding='utf-8') as f:
        f.write(new_content)
    print("  已解锁安装器设置: 公签版强制'A(0)'跳转已改为无条件跳过")
    return True


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 unlock_installer_mode.py <gongqian_apk_dir>")
        sys.exit(1)

    gongqian_dir = sys.argv[1]
    candidates = []
    for sub in ("smali", "smali_classes2", "smali_classes3", "smali_classes4"):
        p = os.path.join(gongqian_dir, sub, "a5", "f.smali")
        if os.path.exists(p):
            candidates.append(p)

    if not candidates:
        print("!! 警告: 未找到 a5/f.smali, 跳过安装器设置解锁")
        return

    for p in candidates:
        print(f"解锁安装器设置: {p}")
        unlock(p)


if __name__ == "__main__":
    main()